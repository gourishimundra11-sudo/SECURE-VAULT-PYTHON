import { useCallback, useEffect, useState } from 'react';
import {
  LayoutDashboard,
  Lock,
  Unlock,
  KeyRound,
  History,
  BookOpen,
  Menu,
  X,
} from 'lucide-react';
import type { ActivityRecord, AppView, DashboardData, ToastNotification } from './types';
import { SecureVaultLogo } from './components/SecureVaultLogo';
import { ToastContainer } from './components/Toast';
import { DashboardView } from './components/DashboardView';
import { EncryptView } from './components/EncryptView';
import { DecryptView } from './components/DecryptView';
import { KeyManagementView } from './components/KeyManagementView';
import { HistoryView } from './components/HistoryView';
import { SecurityGuideView } from './components/SecurityGuideView';

const NAV_ITEMS: Array<{ id: AppView; label: string; icon: typeof LayoutDashboard }> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'encrypt', label: 'Encrypt File', icon: Lock },
  { id: 'decrypt', label: 'Decrypt File', icon: Unlock },
  { id: 'keys', label: 'Key Management', icon: KeyRound },
  { id: 'history', label: 'Activity History', icon: History },
  { id: 'guide', label: 'Security Guide', icon: BookOpen },
];

const VIEW_TITLES: Record<AppView, string> = {
  dashboard: 'Dashboard',
  encrypt: 'Encrypt File',
  decrypt: 'Decrypt File',
  keys: 'Key Management',
  history: 'Activity History',
  guide: 'Security Guide',
};

export default function App() {
  const [activeView, setActiveView] = useState<AppView>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Kept strictly in React memory for the active session; never persisted to localStorage or logs
  const [sessionKey, setSessionKey] = useState<string>('');
  const [preselectedDecryptFile, setPreselectedDecryptFile] = useState<string | null>(null);

  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [historyRecords, setHistoryRecords] = useState<ActivityRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const pushToast = useCallback(
    (toast: Omit<ToastNotification, 'id'>) => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setToasts((prev) => [...prev.slice(-3), { ...toast, id }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 4200);
    },
    []
  );

  const fetchVaultState = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const [dashRes, histRes] = await Promise.all([
        fetch('/api/dashboard'),
        fetch('/api/history'),
      ]);
      if (!dashRes.ok || !histRes.ok) {
        throw new Error('Unable to load vault data from the server.');
      }
      const dashJson = (await dashRes.json()) as DashboardData;
      const histJson = (await histRes.json()) as { records: ActivityRecord[] };
      setDashboardData(dashJson);
      setHistoryRecords(histJson.records || []);
    } catch (err) {
      setLoadError(
        err instanceof Error ? err.message : 'Unable to connect to the SecureVault server.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchVaultState();
  }, [fetchVaultState]);

  const handleNavigate = (view: AppView) => {
    setActiveView(view);
    setMobileMenuOpen(false);
  };

  const handleProceedToDecrypt = (encryptedFilename: string) => {
    setPreselectedDecryptFile(encryptedFilename);
    setActiveView('decrypt');
  };

  return (
    <div className="sv-cyber-grid min-h-screen text-[#F5F3FF] flex">
      {/* Mobile Sidebar Backdrop */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/70 backdrop-blur-xs lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Left Sidebar Navigation */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-white/10 bg-[#0B0B14]/95 backdrop-blur-md transition-transform duration-150 lg:static lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-16 items-center justify-between border-b border-white/10 px-5">
          <button
            type="button"
            onClick={() => handleNavigate('dashboard')}
            className="text-left focus-visible:outline-2 focus-visible:outline-[#B69AFF] rounded-md"
          >
            <SecureVaultLogo variant="sidebar" />
          </button>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(false)}
            className="rounded-md p-1.5 text-[#A6A3B8] hover:bg-white/5 hover:text-[#F5F3FF] lg:hidden"
            aria-label="Close navigation menu"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 px-3 py-5" aria-label="Primary navigation">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavigate(item.id)}
                className={`flex w-full items-center gap-3 rounded-lg px-3.5 py-2.5 text-sm font-medium transition-all duration-150 whitespace-nowrap ${
                  isActive
                    ? 'border border-[#873CFF]/40 bg-[#873CFF]/18 text-[#F5F3FF] shadow-sm shadow-[#873CFF]/10'
                    : 'border border-transparent text-[#A6A3B8] hover:bg-white/[0.04] hover:text-[#F5F3FF]'
                }`}
              >
                <Icon
                  className={`h-4 w-4 shrink-0 ${
                    isActive ? 'text-[#B69AFF]' : 'text-[#A6A3B8]'
                  }`}
                />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Session Key & Version Footer */}
        <div className="border-t border-white/10 px-5 py-4 text-xs space-y-3">
          <div>
            <p className="text-[#A6A3B8]">Session Key</p>
            <p
              className={`mt-1 font-medium ${
                sessionKey ? 'text-[#27D99A]' : 'text-[#F5F3FF]'
              }`}
            >
              {sessionKey ? 'Loaded in memory' : 'Not loaded'}
            </p>
            <button
              type="button"
              onClick={() => handleNavigate('keys')}
              className="mt-1.5 text-xs font-medium text-[#B69AFF] hover:text-white whitespace-nowrap"
            >
              {sessionKey ? 'Manage session key' : 'Generate or load key'}
            </button>
          </div>
          <div className="border-t border-white/10 pt-3 flex items-center justify-between text-[#A6A3B8]">
            <span>SecureVault</span>
            <span className="font-mono tabular-nums">v1.0</span>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between gap-4 border-b border-white/10 bg-[#080810]/85 px-4 backdrop-blur-md sm:px-8">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="rounded-md p-2 text-[#A6A3B8] hover:bg-white/5 hover:text-[#F5F3FF] lg:hidden"
              aria-label="Open navigation menu"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2.5 text-sm text-[#A6A3B8] whitespace-nowrap truncate">
              <span className="lg:hidden">
                <SecureVaultLogo variant="icon" />
              </span>
              <span className="hidden sm:inline text-[#A6A3B8]">SecureVault</span>
              <span className="hidden sm:inline" aria-hidden="true">
                /
              </span>
              <span className="font-medium text-[#F5F3FF]">{VIEW_TITLES[activeView]}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {activeView !== 'encrypt' && (
              <button
                type="button"
                onClick={() => handleNavigate('encrypt')}
                className="inline-flex items-center gap-2 rounded-lg bg-[#873CFF] px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-[#752CE8] whitespace-nowrap shrink-0"
              >
                <Lock className="h-3.5 w-3.5" />
                Encrypt File
              </button>
            )}
          </div>
        </header>

        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-8">
          {activeView === 'dashboard' && (
            <DashboardView
              data={dashboardData}
              loading={loading}
              error={loadError}
              hasSessionKey={Boolean(sessionKey)}
              onNavigate={handleNavigate}
              onRefresh={fetchVaultState}
            />
          )}

          {activeView === 'encrypt' && (
            <EncryptView
              sessionKey={sessionKey}
              onSetSessionKey={setSessionKey}
              sampleFiles={dashboardData?.vaultFiles.samples ?? []}
              onOperationComplete={fetchVaultState}
              onProceedToDecrypt={handleProceedToDecrypt}
              onNotify={pushToast}
            />
          )}

          {activeView === 'decrypt' && (
            <DecryptView
              sessionKey={sessionKey}
              encryptedFiles={dashboardData?.vaultFiles.encrypted ?? []}
              preselectedVaultFile={preselectedDecryptFile}
              onClearPreselected={() => setPreselectedDecryptFile(null)}
              onOperationComplete={fetchVaultState}
              onNotify={pushToast}
            />
          )}

          {activeView === 'keys' && (
            <KeyManagementView
              sessionKey={sessionKey}
              onSetSessionKey={setSessionKey}
              onClearSessionKey={() => setSessionKey('')}
              onNotify={pushToast}
            />
          )}

          {activeView === 'history' && (
            <HistoryView
              records={historyRecords}
              loading={loading}
              onRefresh={fetchVaultState}
            />
          )}

          {activeView === 'guide' && <SecurityGuideView onNavigate={handleNavigate} />}
        </main>
      </div>

      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
