import React, { useState } from 'react';
import {
  Lock,
  Unlock,
  KeyRound,
  ArrowRight,
  CheckCircle2,
  XCircle,
  History,
  FileText,
  ShieldCheck,
  BookOpen,
} from 'lucide-react';
import type { AppView, DashboardData } from '../types';
import { formatTimestamp } from '../utils/format';

interface DashboardViewProps {
  data: DashboardData | null;
  loading: boolean;
  error: string | null;
  hasSessionKey: boolean;
  onNavigate: (view: AppView) => void;
  onRefresh: () => void;
}

const HERO_IMAGE_PATH = '/src/assets/images/hero_vault_shield_1795595009121.jpg';

export const DashboardView: React.FC<DashboardViewProps> = ({
  data,
  loading,
  error,
  hasSessionKey,
  onNavigate,
  onRefresh,
}) => {
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  const stats = data?.stats ?? {
    totalProcessed: 0,
    successfulEncryptions: 0,
    successfulDecryptions: 0,
    failedOperations: 0,
  };

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="sv-glass-panel relative overflow-hidden rounded-2xl">
        <div className="grid grid-cols-1 items-stretch lg:grid-cols-12">
          <div className="flex flex-col justify-center p-6 sm:p-8 lg:col-span-7 lg:p-10">
            <div className="flex items-center gap-2 text-xs font-medium text-[#B69AFF]">
              <ShieldCheck className="h-4 w-4" />
              <span>Fernet Symmetric Cryptography</span>
              <span aria-hidden="true">·</span>
              <span>AES-128-CBC + HMAC-SHA256</span>
            </div>

            <h1 className="mt-3 font-display text-3xl font-bold tracking-tight text-[#F5F3FF] sm:text-4xl text-balance">
              SecureVault
            </h1>
            <p className="mt-2 font-display text-lg font-medium text-[#B69AFF] text-balance">
              Encrypt and decrypt your files with confidence.
            </p>
            <p className="mt-3 max-w-xl text-sm leading-relaxed text-[#A6A3B8]">
              A secure, modern utility to protect your data using industry-standard encryption.
              Generate cryptographic keys in memory, seal plain-text files into authenticated{' '}
              <span className="font-mono text-xs text-[#F5F3FF]">.enc</span> artifacts, and audit
              every operation cleanly.
            </p>

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => onNavigate('encrypt')}
                className="inline-flex items-center gap-2 rounded-lg bg-[#873CFF] px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#752CE8] whitespace-nowrap shrink-0"
              >
                <Lock className="h-4 w-4" />
                Encrypt File
              </button>
              <button
                type="button"
                onClick={() => onNavigate('keys')}
                className="inline-flex items-center gap-2 rounded-lg border border-[#B69AFF]/25 bg-[#080810]/60 px-4 py-2.5 text-sm font-medium text-[#F5F3FF] transition-colors hover:border-[#B69AFF]/50 hover:bg-white/5 whitespace-nowrap shrink-0"
              >
                <KeyRound className="h-4 w-4 text-[#B69AFF]" />
                {hasSessionKey ? 'Manage Active Key' : 'Generate Key'}
              </button>
            </div>
          </div>

          <div className="relative min-h-[220px] border-t border-white/10 bg-[#080810] lg:col-span-5 lg:min-h-[280px] lg:border-t-0 lg:border-l">
            {!heroImgFailed ? (
              <>
                <img
                  src={HERO_IMAGE_PATH}
                  alt="SecureVault metallic shield and padlock with circular protection orbit"
                  referrerPolicy="no-referrer"
                  onError={() => setHeroImgFailed(true)}
                  className="h-full w-full object-cover object-center lg:absolute lg:inset-0"
                />
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0 bg-gradient-to-r from-[#11111D]/80 via-transparent to-transparent lg:block hidden"
                />
              </>
            ) : (
              <div className="flex h-full min-h-[240px] flex-col items-center justify-center bg-gradient-to-br from-[#11111D] via-[#080810] to-[#1A1333] p-6 text-center">
                <ShieldCheck className="h-12 w-12 text-[#873CFF]" />
                <p className="mt-3 font-display text-sm font-semibold text-[#F5F3FF]">
                  Authenticated Vault Protection
                </p>
              </div>
            )}
          </div>
        </div>
      </section>

      {error && (
        <div className="flex items-center justify-between gap-4 rounded-xl border border-rose-500/35 bg-rose-950/30 px-4 py-3 text-sm text-rose-200">
          <span>{error}</span>
          <button
            type="button"
            onClick={onRefresh}
            className="rounded-md border border-rose-400/30 bg-[#11111D] px-3 py-1 text-xs font-medium text-rose-200 hover:bg-white/5 whitespace-nowrap shrink-0"
          >
            Retry
          </button>
        </div>
      )}

      {/* Three Real Statistics Cards */}
      <section
        aria-label="Vault statistics"
        className="grid grid-cols-1 gap-4 md:grid-cols-3"
      >
        <div className="sv-glass-panel rounded-xl p-5 transition-colors hover:border-[#B69AFF]/30">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-[#A6A3B8]">Total Files Processed</p>
            <FileText className="h-4 w-4 text-[#B69AFF]" />
          </div>
          <p className="mt-3 font-mono text-3xl font-semibold tracking-tight text-[#F5F3FF] tabular-nums">
            {loading && !data ? '—' : stats.totalProcessed}
          </p>
          <p className="mt-1.5 text-xs text-[#A6A3B8]">
            {stats.failedOperations > 0
              ? `${stats.failedOperations} blocked or failed validation`
              : 'All recorded encryption and decryption events'}
          </p>
        </div>

        <div className="sv-glass-panel rounded-xl p-5 transition-colors hover:border-[#873CFF]/45">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-[#A6A3B8]">Successful Encryptions</p>
            <Lock className="h-4 w-4 text-[#873CFF]" />
          </div>
          <p className="mt-3 font-mono text-3xl font-semibold tracking-tight text-[#B69AFF] tabular-nums">
            {loading && !data ? '—' : stats.successfulEncryptions}
          </p>
          <p className="mt-1.5 text-xs text-[#A6A3B8]">
            Plain-text documents sealed to .enc format
          </p>
        </div>

        <div className="sv-glass-panel rounded-xl p-5 transition-colors hover:border-[#27D99A]/40">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-[#A6A3B8]">Successful Decryptions</p>
            <Unlock className="h-4 w-4 text-[#27D99A]" />
          </div>
          <p className="mt-3 font-mono text-3xl font-semibold tracking-tight text-[#27D99A] tabular-nums">
            {loading && !data ? '—' : stats.successfulDecryptions}
          </p>
          <p className="mt-1.5 text-xs text-[#A6A3B8]">
            HMAC-verified .enc artifacts restored cleanly
          </p>
        </div>
      </section>

      {/* Three Visually Distinct Action Cards */}
      <section aria-label="Quick security actions" className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        {/* 1. Encrypt File - Purple Accent */}
        <div
          onClick={() => onNavigate('encrypt')}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              onNavigate('encrypt');
            }
          }}
          className="group flex cursor-pointer flex-col justify-between rounded-xl border border-[#873CFF]/30 bg-gradient-to-br from-[#873CFF]/15 via-[#11111D] to-[#11111D] p-6 transition-all duration-150 hover:-translate-y-0.5 hover:border-[#873CFF]/65 focus-visible:outline-2 focus-visible:outline-[#B69AFF]"
        >
          <div>
            <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#873CFF]/35 bg-[#873CFF]/20 text-[#B69AFF]">
              <Lock className="h-5 w-5" />
            </div>
            <h2 className="mt-4 font-display text-base font-semibold text-[#F5F3FF]">
              Encrypt File
            </h2>
            <p className="mt-1.5 text-sm leading-relaxed text-[#A6A3B8]">
              Lock <span className="font-mono text-xs text-[#F5F3FF]">.txt</span> documents with
              authenticated Fernet cryptography and save tamper-evident{' '}
              <span className="font-mono text-xs text-[#F5F3FF]">.enc</span> files.
            </p>
          </div>
          <div className="mt-5 pt-4 border-t border-white/10">
            <span className="inline-flex items-center gap-1.5 text-sm font-medium text-[#B69AFF] group-hover:text-white">
              Start Encryption
              <ArrowRight className="h-4 w-4 transition-transform duration-150 group-hover:translate-x-0.5" />
            </span>
          </div>
        </div>

        {/* 2. Decrypt File - Blue Accent */}
        <div
          onClick={() => onNavigate('decrypt')}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              onNavigate('decrypt');
            }
          }}
          className="group flex cursor-pointer flex-col justify-between rounded-xl border border-[#3478FF]/30 bg-gradient-to-br from-[#3478FF]/15 via-[#11111D] to-[#11111D] p-6 transition-all duration-150 hover:-translate-y-0.5 hover:border-[#3478FF]/65 focus-visible:outline-2 focus-visible:outline-[#3478FF]"
        >
          <div>
            <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#3478FF]/35 bg-[#3478FF]/20 text-[#7CB0FF]">
              <Unlock className="h-5 w-5" />
            </div>
            <h2 className="mt-4 font-display text-base font-semibold text-[#F5F3FF]">
              Decrypt File
            </h2>
            <p className="mt-1.5 text-sm leading-relaxed text-[#A6A3B8]">
              Verify HMAC-SHA256 signatures on{' '}
              <span className="font-mono text-xs text-[#F5F3FF]">.enc</span> artifacts and restore
              original plain-text content into a separate file.
            </p>
          </div>
          <div className="mt-5 pt-4 border-t border-white/10">
            <span className="inline-flex items-center gap-1.5 text-sm font-medium text-[#7CB0FF] group-hover:text-white">
              Open Decryption
              <ArrowRight className="h-4 w-4 transition-transform duration-150 group-hover:translate-x-0.5" />
            </span>
          </div>
        </div>

        {/* 3. Key Management - Green Accent */}
        <div
          onClick={() => onNavigate('keys')}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              onNavigate('keys');
            }
          }}
          className="group flex cursor-pointer flex-col justify-between rounded-xl border border-[#27D99A]/30 bg-gradient-to-br from-[#27D99A]/14 via-[#11111D] to-[#11111D] p-6 transition-all duration-150 hover:-translate-y-0.5 hover:border-[#27D99A]/65 focus-visible:outline-2 focus-visible:outline-[#27D99A]"
        >
          <div>
            <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#27D99A]/35 bg-[#27D99A]/15 text-[#27D99A]">
              <KeyRound className="h-5 w-5" />
            </div>
            <h2 className="mt-4 font-display text-base font-semibold text-[#F5F3FF]">
              Key Management
            </h2>
            <p className="mt-1.5 text-sm leading-relaxed text-[#A6A3B8]">
              Generate 32-byte Fernet keys, load existing{' '}
              <span className="font-mono text-xs text-[#F5F3FF]">.key</span> files, and export
              secure backups without exposing secrets in logs.
            </p>
          </div>
          <div className="mt-5 pt-4 border-t border-white/10">
            <span className="inline-flex items-center gap-1.5 text-sm font-medium text-[#27D99A] group-hover:text-white">
              Manage Keys
              <ArrowRight className="h-4 w-4 transition-transform duration-150 group-hover:translate-x-0.5" />
            </span>
          </div>
        </div>
      </section>

      {/* Recent Activity & Compact Security Tips */}
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-12 items-start">
        <section className="sv-glass-panel overflow-hidden rounded-xl xl:col-span-8">
          <div className="flex items-center justify-between gap-4 border-b border-white/10 px-6 py-4">
            <div>
              <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
                Recent Activity
              </h2>
              <p className="mt-0.5 text-xs text-[#A6A3B8]">
                Latest audited vault events. Secret keys are never recorded.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#080810]/70 px-3 py-1.5 text-xs font-medium text-[#F5F3FF] transition-colors hover:border-[#B69AFF]/45 hover:bg-white/5 whitespace-nowrap shrink-0"
            >
              <History className="h-3.5 w-3.5 text-[#B69AFF]" />
              View All
            </button>
          </div>

          {loading && !data ? (
            <div className="divide-y divide-white/10 px-6 py-2">
              {[1, 2, 3].map((row) => (
                <div key={row} className="flex items-center justify-between py-3.5">
                  <div className="h-4 w-48 animate-pulse rounded bg-white/10" />
                  <div className="h-4 w-24 animate-pulse rounded bg-white/5" />
                </div>
              ))}
            </div>
          ) : !data || data.recentActivity.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <FileText className="mx-auto h-8 w-8 text-[#A6A3B8]/50" />
              <p className="mt-3 font-display text-sm font-semibold text-[#F5F3FF]">
                No operations recorded yet
              </p>
              <p className="mt-1 text-xs text-[#A6A3B8]">
                Encrypt a sample .txt file or upload your own document to create your first audit entry.
              </p>
              <button
                type="button"
                onClick={() => onNavigate('encrypt')}
                className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[#873CFF] px-4 py-2 text-xs font-medium text-white hover:bg-[#752CE8] whitespace-nowrap"
              >
                Encrypt First File
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-white/10 bg-[#080810]/60 text-xs font-medium text-[#A6A3B8]">
                    <th className="px-6 py-3">Filename</th>
                    <th className="px-4 py-3">Operation</th>
                    <th className="px-4 py-3">Date &amp; Time</th>
                    <th className="px-6 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10">
                  {data.recentActivity.map((item) => (
                    <tr key={item.id} className="transition-colors hover:bg-white/[0.03]">
                      <td className="px-6 py-3 font-mono text-xs font-medium text-[#F5F3FF]">
                        {item.filename}
                      </td>
                      <td className="px-4 py-3 text-xs capitalize text-[#A6A3B8]">
                        {item.operation}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-[#A6A3B8] tabular-nums whitespace-nowrap">
                        {formatTimestamp(item.timestamp)}
                      </td>
                      <td className="px-6 py-3 text-xs whitespace-nowrap">
                        {item.status === 'success' ? (
                          <span className="inline-flex items-center gap-1.5 font-medium text-[#27D99A]">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Success
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 font-medium text-rose-400">
                            <XCircle className="h-3.5 w-3.5" />
                            Failed
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Compact Security Tips Panel */}
        <aside className="sv-glass-panel rounded-xl p-6 xl:col-span-4 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
              Security Tips
            </h2>
            <ShieldCheck className="h-4 w-4 text-[#B69AFF]" />
          </div>

          <ul className="divide-y divide-white/10 text-xs leading-relaxed text-[#A6A3B8]">
            <li className="pb-3">
              <p className="font-medium text-[#F5F3FF]">Separate Keys From Ciphertext</p>
              <p className="mt-1">
                Never store your <span className="font-mono text-[#F5F3FF]">.key</span> file in the
                same folder or cloud drive as your{' '}
                <span className="font-mono text-[#F5F3FF]">.enc</span> archives.
              </p>
            </li>
            <li className="py-3">
              <p className="font-medium text-[#F5F3FF]">Back Up Before Rotating</p>
              <p className="mt-1">
                Fernet has zero key-recovery backdoors. Losing a key permanently prevents
                decrypting files sealed with it.
              </p>
            </li>
            <li className="pt-3">
              <p className="font-medium text-[#F5F3FF]">Verify Integrity Automatically</p>
              <p className="mt-1">
                Modified or truncated <span className="font-mono text-[#F5F3FF]">.enc</span> files
                are blocked before decryption using constant-time HMAC checks.
              </p>
            </li>
          </ul>

          <button
            type="button"
            onClick={() => onNavigate('guide')}
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-white/15 bg-[#080810]/70 px-3.5 py-2 text-xs font-medium text-[#F5F3FF] transition-colors hover:border-[#B69AFF]/45 hover:bg-white/5"
          >
            <BookOpen className="h-3.5 w-3.5 text-[#B69AFF]" />
            Read Full Security Guide
          </button>
        </aside>
      </div>
    </div>
  );
};
