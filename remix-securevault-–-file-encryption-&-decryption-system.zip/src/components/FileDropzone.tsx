import React, { useRef, useState } from 'react';
import {
  Upload,
  FileText,
  FileLock2,
  CheckCircle2,
  AlertCircle,
  X,
  FolderOpen,
} from 'lucide-react';
import type { SelectedFileState, VaultFileSummary } from '../types';
import { formatBytes, readFileAsBase64 } from '../utils/format';

interface FileDropzoneProps {
  mode: 'encrypt' | 'decrypt';
  selectedFile: SelectedFileState | null;
  onSelectFile: (file: SelectedFileState | null) => void;
  vaultFiles: VaultFileSummary[];
}

export const FileDropzone: React.FC<FileDropzoneProps> = ({
  mode,
  selectedFile,
  onSelectFile,
  vaultFiles,
}) => {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [readProgress, setReadProgress] = useState<number | null>(null);
  const [readError, setReadError] = useState<string | null>(null);

  const expectedExt = mode === 'encrypt' ? '.txt' : '.enc';
  const accentBtn =
    mode === 'encrypt'
      ? 'bg-[#873CFF] hover:bg-[#752CE8] focus-visible:outline-[#B69AFF]'
      : 'bg-[#3478FF] hover:bg-[#2563EB] focus-visible:outline-[#3478FF]';

  const dragBorder =
    mode === 'encrypt'
      ? 'border-[#873CFF] bg-[#873CFF]/10'
      : 'border-[#3478FF] bg-[#3478FF]/10';

  const processLocalFile = async (file: File) => {
    setReadError(null);
    const filename = file.name.trim();
    const lower = filename.toLowerCase();
    const hasExpectedExt = lower.endsWith(expectedExt);

    if (file.size === 0) {
      onSelectFile({
        source: 'upload',
        filename,
        sizeBytes: 0,
        mimeType: file.type || 'unknown',
        isValid: false,
        validationMessage: `The selected file "${filename}" is empty (0 bytes) and cannot be processed.`,
      });
      return;
    }

    if (!hasExpectedExt) {
      onSelectFile({
        source: 'upload',
        filename,
        sizeBytes: file.size,
        mimeType: file.type || 'unknown',
        isValid: false,
        validationMessage:
          mode === 'encrypt'
            ? `Unsupported format "${filename}". Only .txt plain-text files are supported for encryption.`
            : `Unsupported format "${filename}". Only .enc encrypted files are supported for decryption.`,
      });
      return;
    }

    try {
      setReadProgress(35);
      const contentBase64 = await readFileAsBase64(file);
      setReadProgress(100);
      setTimeout(() => setReadProgress(null), 220);
      onSelectFile({
        source: 'upload',
        filename,
        sizeBytes: file.size,
        mimeType:
          file.type || (mode === 'encrypt' ? 'text/plain' : 'application/octet-stream'),
        contentBase64,
        isValid: true,
        validationMessage:
          mode === 'encrypt'
            ? 'Validated .txt document ready for Fernet encryption.'
            : 'Validated .enc file ready for key verification and decryption.',
      });
    } catch (err) {
      setReadProgress(null);
      setReadError(err instanceof Error ? err.message : 'Failed to read file.');
    }
  };

  const handleInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await processLocalFile(file);
    }
    e.target.value = '';
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      await processLocalFile(file);
    }
  };

  const handleSelectVaultFile = (vf: VaultFileSummary) => {
    setReadError(null);
    onSelectFile({
      source: 'vault',
      filename: vf.filename,
      sizeBytes: vf.sizeBytes,
      mimeType: mode === 'encrypt' ? 'text/plain' : 'application/octet-stream',
      vaultName: vf.filename,
      isValid: vf.sizeBytes > 0,
      validationMessage:
        vf.sizeBytes > 0
          ? `Loaded from ${vf.relativePath} and ready to process.`
          : 'Selected vault file is empty.',
    });
  };

  return (
    <div className="space-y-5">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`rounded-xl border border-dashed p-8 text-center transition-colors duration-150 ${
          isDragging
            ? dragBorder
            : 'border-[#B69AFF]/25 bg-[#080810]/60 hover:border-[#B69AFF]/45'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept={expectedExt}
          onChange={handleInputChange}
          className="hidden"
          aria-label={mode === 'encrypt' ? 'Select a .txt file' : 'Select a .enc file'}
        />
        <div className="mx-auto mb-3.5 flex h-12 w-12 items-center justify-center rounded-xl border border-[#B69AFF]/20 bg-[#11111D] text-[#B69AFF]">
          <Upload className="h-5 w-5" />
        </div>
        <p className="font-display text-sm font-semibold text-[#F5F3FF]">
          {mode === 'encrypt'
            ? 'Drag and drop a .txt file here'
            : 'Drag and drop an encrypted .enc file here'}
        </p>
        <p className="mt-1.5 text-xs text-[#A6A3B8]">
          {mode === 'encrypt'
            ? 'Supported format: .txt (up to 5 MB). Empty or unsupported formats are blocked.'
            : 'Supported format: .enc Fernet ciphertext artifacts.'}
        </p>

        {readProgress !== null && (
          <div className="mx-auto mt-4 max-w-xs">
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
              <div
                className={`h-full transition-all duration-200 ${
                  mode === 'encrypt' ? 'bg-[#873CFF]' : 'bg-[#3478FF]'
                }`}
                style={{ width: `${readProgress}%` }}
              />
            </div>
            <p className="mt-1.5 font-mono text-[11px] text-[#A6A3B8] tabular-nums">
              Reading file {readProgress}%
            </p>
          </div>
        )}

        <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium text-white transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 whitespace-nowrap shrink-0 ${accentBtn}`}
          >
            <FolderOpen className="h-4 w-4" />
            Select File
          </button>
          {selectedFile && (
            <button
              type="button"
              onClick={() => onSelectFile(null)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#11111D] px-3.5 py-2 text-sm font-medium text-[#A6A3B8] transition-colors hover:border-white/25 hover:text-[#F5F3FF] whitespace-nowrap shrink-0"
            >
              <X className="h-4 w-4" />
              Clear Selection
            </button>
          )}
        </div>
      </div>

      {readError && (
        <div className="flex items-start gap-2.5 rounded-lg border border-rose-500/35 bg-rose-950/30 px-4 py-3 text-sm text-rose-200">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
          <span>{readError}</span>
        </div>
      )}

      {selectedFile && (
        <div
          className={`rounded-xl border px-4 py-3.5 ${
            selectedFile.isValid
              ? 'border-[#B69AFF]/20 bg-[#080810]/70'
              : 'border-rose-500/35 bg-rose-950/20'
          }`}
        >
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-start gap-3 min-w-0">
              <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-[#11111D] text-[#B69AFF]">
                {mode === 'encrypt' ? (
                  <FileText className="h-4 w-4" />
                ) : (
                  <FileLock2 className="h-4 w-4" />
                )}
              </div>
              <div className="min-w-0">
                <p className="truncate font-mono text-sm font-medium text-[#F5F3FF]">
                  {selectedFile.filename}
                </p>
                <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-[#A6A3B8]">
                  <span className="font-mono tabular-nums">
                    {formatBytes(selectedFile.sizeBytes)}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedFile.mimeType}</span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {selectedFile.source === 'vault' ? 'Vault directory' : 'Local upload'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-xs font-medium shrink-0">
              {selectedFile.isValid ? (
                <span className="inline-flex items-center gap-1.5 text-[#27D99A]">
                  <CheckCircle2 className="h-4 w-4" />
                  Validated
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-rose-400">
                  <AlertCircle className="h-4 w-4" />
                  Invalid File
                </span>
              )}
            </div>
          </div>
          <p
            className={`mt-2.5 border-t pt-2.5 text-xs ${
              selectedFile.isValid
                ? 'border-white/10 text-[#A6A3B8]'
                : 'border-rose-500/25 text-rose-300'
            }`}
          >
            {selectedFile.validationMessage}
          </p>
        </div>
      )}

      {vaultFiles.length > 0 && (
        <div className="border-t border-white/10 pt-4">
          <div className="mb-2.5 flex items-center justify-between">
            <h4 className="text-xs font-semibold text-[#F5F3FF]">
              {mode === 'encrypt'
                ? 'Or load a sample .txt file from Vault'
                : 'Or select an encrypted .enc file from Vault'}
            </h4>
            <span className="font-mono text-xs text-[#A6A3B8] tabular-nums">
              {vaultFiles.length} available
            </span>
          </div>
          <div className="divide-y divide-white/10 overflow-hidden rounded-xl border border-white/10 bg-[#080810]/60">
            {vaultFiles.slice(0, 5).map((vf) => {
              const isSelected =
                selectedFile?.source === 'vault' && selectedFile.filename === vf.filename;
              return (
                <button
                  key={vf.relativePath}
                  type="button"
                  onClick={() => handleSelectVaultFile(vf)}
                  className={`flex w-full items-center justify-between gap-4 px-3.5 py-2.5 text-left text-sm transition-colors ${
                    isSelected
                      ? mode === 'encrypt'
                        ? 'bg-[#873CFF]/15'
                        : 'bg-[#3478FF]/15'
                      : 'hover:bg-white/[0.04]'
                  }`}
                >
                  <div className="min-w-0">
                    <p className="truncate font-mono text-xs font-medium text-[#F5F3FF]">
                      {vf.filename}
                    </p>
                    <p className="truncate text-xs text-[#A6A3B8]">{vf.relativePath}</p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="font-mono text-xs text-[#A6A3B8] tabular-nums">
                      {formatBytes(vf.sizeBytes)}
                    </span>
                    <span
                      className={`text-xs font-medium ${
                        isSelected
                          ? mode === 'encrypt'
                            ? 'text-[#B69AFF]'
                            : 'text-[#3478FF]'
                          : 'text-[#A6A3B8]'
                      }`}
                    >
                      {isSelected ? 'Selected' : 'Select'}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
