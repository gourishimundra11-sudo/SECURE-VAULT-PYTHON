import React, { useEffect, useState } from 'react';
import {
  Unlock,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Download,
  Eye,
  EyeOff,
  FolderCheck,
  Loader2,
} from 'lucide-react';
import type { SelectedFileState, VaultFileSummary } from '../types';
import { FileDropzone } from './FileDropzone';
import { formatBytes, formatTimestamp, maskSecretKey } from '../utils/format';

interface DecryptResult {
  inputFilename: string;
  outputFilename: string;
  outputLocation: string;
  inputSizeBytes: number;
  outputSizeBytes: number;
  renamedDueToDuplicate: boolean;
  encryptedAt: string;
  message: string;
  decryptedPreview: string;
}

interface DecryptViewProps {
  sessionKey: string;
  encryptedFiles: VaultFileSummary[];
  preselectedVaultFile: string | null;
  onClearPreselected: () => void;
  onOperationComplete: () => void;
  onNotify: (toast: { type: 'success' | 'error' | 'info'; title: string; description?: string }) => void;
}

export const DecryptView: React.FC<DecryptViewProps> = ({
  sessionKey,
  encryptedFiles,
  preselectedVaultFile,
  onClearPreselected,
  onOperationComplete,
  onNotify,
}) => {
  const [selectedFile, setSelectedFile] = useState<SelectedFileState | null>(null);
  const [keyMode, setKeyMode] = useState<'session' | 'custom'>(sessionKey ? 'session' : 'custom');
  const [customKey, setCustomKey] = useState('');
  const [showCustomKey, setShowCustomKey] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<DecryptResult | null>(null);

  useEffect(() => {
    if (preselectedVaultFile) {
      const match = encryptedFiles.find((f) => f.filename === preselectedVaultFile);
      if (match) {
        setSelectedFile({
          source: 'vault',
          filename: match.filename,
          sizeBytes: match.sizeBytes,
          mimeType: 'application/octet-stream',
          vaultName: match.filename,
          isValid: match.sizeBytes > 0,
          validationMessage: `Loaded from ${match.relativePath} and ready for decryption.`,
        });
        setResult(null);
        setError(null);
      }
      onClearPreselected();
    }
  }, [preselectedVaultFile, encryptedFiles, onClearPreselected]);

  const activeKey = keyMode === 'session' ? sessionKey : customKey.trim();

  const handleKeyFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const text = (await file.text()).trim();
      setCustomKey(text);
      setKeyMode('custom');
      setError(null);
      onNotify({ type: 'info', title: 'Key file loaded', description: `Loaded ${file.name} for decryption.` });
    } catch {
      setError('Unable to read the selected .key file.');
    }
  };

  const handleDecrypt = async () => {
    setError(null);
    setResult(null);

    if (!selectedFile) {
      const msg = 'Missing file: please select or drop an encrypted .enc file.';
      setError(msg);
      onNotify({ type: 'error', title: 'No encrypted file selected', description: msg });
      return;
    }
    if (!selectedFile.isValid) {
      setError(selectedFile.validationMessage);
      onNotify({ type: 'error', title: 'Invalid input file', description: selectedFile.validationMessage });
      return;
    }
    if (!activeKey) {
      const msg = 'Missing decryption key: provide the Fernet key used to encrypt this file.';
      setError(msg);
      onNotify({ type: 'error', title: 'Decryption key required', description: msg });
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/decrypt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: selectedFile.filename,
          vaultEncryptedName:
            selectedFile.source === 'vault' ? selectedFile.vaultName : undefined,
          contentBase64:
            selectedFile.source === 'upload' ? selectedFile.contentBase64 : undefined,
          key: activeKey,
        }),
      });
      const data = await res.json();
      onOperationComplete();

      if (!res.ok) {
        const msg = data.error || 'Decryption failed.';
        setError(msg);
        onNotify({ type: 'error', title: 'Decryption failed', description: msg });
        return;
      }

      setResult(data as DecryptResult);
      onNotify({
        type: 'success',
        title: 'File decrypted successfully',
        description: `Restored as ${data.outputFilename}`,
      });
    } catch {
      const msg = 'Network or server error while decrypting the file. Please try again.';
      setError(msg);
      onNotify({ type: 'error', title: 'Connection error', description: msg });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDownloadOutput = () => {
    if (!result) return;
    window.location.assign(
      `/api/vault/download?category=decrypted&filename=${encodeURIComponent(result.outputFilename)}`
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold tracking-tight text-[#F5F3FF]">
          Decrypt Encrypted Artifact
        </h1>
        <p className="mt-1 text-sm text-[#A6A3B8]">
          Select an encrypted <span className="font-mono text-xs text-[#F5F3FF]">.enc</span> file
          and supply its corresponding Fernet key. HMAC integrity is validated before writing the
          recovered document.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 items-start">
        <div className="space-y-6 lg:col-span-7">
          <div className="sv-glass-panel rounded-xl p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
                01. Select Encrypted File
              </h2>
              <span className="font-mono text-xs text-[#7CB0FF]">Format: .enc</span>
            </div>
            <FileDropzone
              mode="decrypt"
              selectedFile={selectedFile}
              onSelectFile={(f) => {
                setSelectedFile(f);
                setResult(null);
                setError(null);
              }}
              vaultFiles={encryptedFiles}
            />
          </div>

          <div className="sv-glass-panel rounded-xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
                02. Decryption Key
              </h2>
              <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-[#080810] p-1">
                <button
                  type="button"
                  onClick={() => setKeyMode('session')}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                    keyMode === 'session'
                      ? 'bg-[#3478FF] text-white'
                      : 'text-[#A6A3B8] hover:text-[#F5F3FF]'
                  }`}
                >
                  Session Key
                </button>
                <button
                  type="button"
                  onClick={() => setKeyMode('custom')}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                    keyMode === 'custom'
                      ? 'bg-[#873CFF] text-white'
                      : 'text-[#A6A3B8] hover:text-[#F5F3FF]'
                  }`}
                >
                  Enter / Load Key
                </button>
              </div>
            </div>

            {keyMode === 'session' ? (
              sessionKey ? (
                <div className="flex items-center gap-2.5 rounded-xl border border-[#27D99A]/25 bg-[#080810]/70 px-4 py-3">
                  <KeyRound className="h-4 w-4 shrink-0 text-[#27D99A]" />
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-[#F5F3FF]">
                      Using active session key from memory
                    </p>
                    <p className="truncate font-mono text-xs text-[#A6A3B8]">
                      {maskSecretKey(sessionKey)}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="rounded-xl border border-white/10 bg-[#080810]/60 px-4 py-3.5 text-xs text-[#A6A3B8]">
                  No key is currently loaded in session memory. Switch to{' '}
                  <button
                    type="button"
                    onClick={() => setKeyMode('custom')}
                    className="font-medium text-[#7CB0FF] underline hover:text-[#B69AFF]"
                  >
                    Enter / Load Key
                  </button>{' '}
                  to supply your <span className="font-mono text-[#F5F3FF]">.key</span> file or key
                  string.
                </div>
              )
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <label htmlFor="decrypt-key-input" className="text-xs font-medium text-[#F5F3FF]">
                    Corresponding Fernet Key
                  </label>
                  <label className="cursor-pointer text-xs font-medium text-[#7CB0FF] hover:text-[#B69AFF]">
                    Load .key file
                    <input
                      type="file"
                      accept=".key,.txt"
                      onChange={handleKeyFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                <div className="relative">
                  <input
                    id="decrypt-key-input"
                    type={showCustomKey ? 'text' : 'password'}
                    value={customKey}
                    onChange={(e) => setCustomKey(e.target.value)}
                    placeholder="Paste the 44-character Fernet key..."
                    autoComplete="off"
                    spellCheck={false}
                    className="w-full rounded-lg border border-white/15 bg-[#080810] py-2.5 pl-3 pr-10 font-mono text-xs text-[#F5F3FF] placeholder:text-[#A6A3B8]/55 focus:border-[#3478FF] focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCustomKey((v) => !v)}
                    aria-label={showCustomKey ? 'Hide key' : 'Show key'}
                    className="absolute inset-y-0 right-0 flex items-center px-3 text-[#A6A3B8] hover:text-[#F5F3FF]"
                  >
                    {showCustomKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                <p className="text-xs text-[#A6A3B8]">
                  Incorrect keys or tampered ciphertext are rejected automatically via HMAC-SHA256 verification.
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6 lg:col-span-5">
          <div className="sv-glass-panel rounded-xl p-6 space-y-5">
            <div>
              <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
                03. Verify &amp; Decrypt
              </h2>
              <p className="mt-1 text-xs text-[#A6A3B8]">
                Recovers original content into a separate file inside the decrypted vault folder.
              </p>
            </div>

            <dl className="divide-y divide-white/10 border-y border-white/10 text-xs">
              <div className="flex items-center justify-between py-2.5">
                <dt className="text-[#A6A3B8]">Encrypted File</dt>
                <dd className="max-w-[210px] truncate font-mono font-medium text-[#F5F3FF]">
                  {selectedFile ? selectedFile.filename : 'None'}
                </dd>
              </div>
              <div className="flex items-center justify-between py-2.5">
                <dt className="text-[#A6A3B8]">Validation Status</dt>
                <dd className="font-medium text-[#F5F3FF]">
                  {selectedFile
                    ? selectedFile.isValid
                      ? 'Valid .enc artifact'
                      : 'Invalid file'
                    : 'Awaiting file'}
                </dd>
              </div>
              <div className="flex items-center justify-between py-2.5">
                <dt className="text-[#A6A3B8]">Decryption Key</dt>
                <dd className="font-medium text-[#F5F3FF]">
                  {activeKey ? 'Provided (Hidden)' : 'Not provided'}
                </dd>
              </div>
              <div className="flex items-center justify-between py-2.5">
                <dt className="text-[#A6A3B8]">Integrity Check</dt>
                <dd className="font-mono text-[#7CB0FF]">HMAC-SHA256 + PKCS7</dd>
              </div>
            </dl>

            <button
              type="button"
              onClick={handleDecrypt}
              disabled={submitting}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#3478FF] to-[#873CFF] px-4 py-2.5 text-sm font-medium text-white transition-opacity hover:opacity-95 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Verifying &amp; Decrypting...
                </>
              ) : (
                <>
                  <Unlock className="h-4 w-4" />
                  Decrypt Now
                </>
              )}
            </button>

            {error && (
              <div className="flex items-start gap-2.5 rounded-lg border border-rose-500/35 bg-rose-950/30 p-3.5 text-xs leading-relaxed text-rose-200">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            {result && (
              <div className="space-y-4 rounded-xl border border-[#27D99A]/35 bg-[#27D99A]/10 p-4">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#27D99A]" />
                  <div>
                    <p className="text-sm font-semibold text-[#F5F3FF]">
                      Operation Status: Decrypted
                    </p>
                    <p className="mt-0.5 text-xs text-[#A6A3B8]">{result.message}</p>
                  </div>
                </div>

                <dl className="space-y-2 border-t border-white/10 pt-3 text-xs">
                  <div className="flex items-start justify-between gap-2">
                    <dt className="shrink-0 text-[#A6A3B8]">Output File</dt>
                    <dd className="break-all text-right font-mono font-medium text-[#F5F3FF]">
                      {result.outputFilename}
                    </dd>
                  </div>
                  <div className="flex items-start justify-between gap-2">
                    <dt className="shrink-0 text-[#A6A3B8]">Saved Location</dt>
                    <dd className="inline-flex items-center gap-1 break-all text-right font-mono text-[#27D99A]">
                      <FolderCheck className="h-3.5 w-3.5 shrink-0" />
                      {result.outputLocation}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-[#A6A3B8]">Encrypted On</dt>
                    <dd className="font-mono text-[#F5F3FF] tabular-nums">
                      {formatTimestamp(result.encryptedAt)}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-[#A6A3B8]">Recovered Size</dt>
                    <dd className="font-mono text-[#F5F3FF] tabular-nums">
                      {formatBytes(result.outputSizeBytes)}
                    </dd>
                  </div>
                </dl>

                <button
                  type="button"
                  onClick={handleDownloadOutput}
                  className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg bg-[#27D99A] px-3 py-2 text-xs font-semibold text-[#080810] hover:bg-[#22C58B]"
                >
                  <Download className="h-3.5 w-3.5" />
                  Download Decrypted File
                </button>
              </div>
            )}
          </div>

          {result && (
            <div className="sv-glass-panel rounded-xl p-5">
              <div className="mb-2.5 flex items-center justify-between">
                <h3 className="text-xs font-semibold text-[#F5F3FF]">
                  Recovered Content Preview
                </h3>
                <span className="font-mono text-xs text-[#A6A3B8]">UTF-8</span>
              </div>
              <pre className="max-h-64 overflow-auto rounded-lg border border-white/10 bg-[#080810] p-3.5 font-mono text-xs leading-relaxed text-[#F5F3FF] whitespace-pre-wrap">
                {result.decryptedPreview}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
