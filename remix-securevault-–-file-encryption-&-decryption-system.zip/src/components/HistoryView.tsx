import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  Search,
  Download,
  History,
  RefreshCw,
} from 'lucide-react';
import type { ActivityRecord } from '../types';
import { formatBytes, formatTimestamp } from '../utils/format';

interface HistoryViewProps {
  records: ActivityRecord[];
  loading: boolean;
  onRefresh: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  records,
  loading,
  onRefresh,
}) => {
  const [operationFilter, setOperationFilter] = useState<'all' | 'encrypt' | 'decrypt'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'success' | 'failed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredRecords = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return records.filter((item) => {
      if (operationFilter !== 'all' && item.operation !== operationFilter) return false;
      if (statusFilter !== 'all' && item.status !== statusFilter) return false;
      if (q) {
        const hay = `${item.filename} ${item.outputFilename || ''} ${item.message}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [records, operationFilter, statusFilter, searchQuery]);

  const handleDownloadOutput = (record: ActivityRecord) => {
    if (!record.outputFilename || record.status !== 'success') return;
    const category = record.operation === 'encrypt' ? 'encrypted' : 'decrypted';
    window.location.assign(
      `/api/vault/download?category=${category}&filename=${encodeURIComponent(record.outputFilename)}`
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold tracking-tight text-[#F5F3FF]">
            Activity History
          </h1>
          <p className="mt-1 text-sm text-[#A6A3B8]">
            Audited record of encryption and decryption operations. Passwords and encryption keys
            are never stored in activity logs.
          </p>
        </div>
        <button
          type="button"
          onClick={onRefresh}
          className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#11111D] px-3.5 py-2 text-xs font-medium text-[#F5F3FF] transition-colors hover:border-[#B69AFF]/45 hover:bg-white/5 whitespace-nowrap shrink-0"
        >
          <RefreshCw className={`h-3.5 w-3.5 text-[#B69AFF] ${loading ? 'animate-spin' : ''}`} />
          Refresh Log
        </button>
      </div>

      {/* Filter Bar */}
      <div className="sv-glass-panel flex flex-col gap-4 rounded-xl p-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-[#080810] p-1">
            {(
              [
                { id: 'all', label: 'All Operations' },
                { id: 'encrypt', label: 'Encryption' },
                { id: 'decrypt', label: 'Decryption' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setOperationFilter(tab.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                  operationFilter === tab.id
                    ? 'bg-[#873CFF] text-white'
                    : 'text-[#A6A3B8] hover:text-[#F5F3FF]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-[#080810] p-1">
            {(
              [
                { id: 'all', label: 'All Statuses' },
                { id: 'success', label: 'Successful' },
                { id: 'failed', label: 'Failed' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setStatusFilter(tab.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                  statusFilter === tab.id
                    ? 'bg-[#3478FF] text-white'
                    : 'text-[#A6A3B8] hover:text-[#F5F3FF]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="relative w-full lg:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#A6A3B8]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter by filename or result..."
            aria-label="Search activity history"
            className="w-full rounded-lg border border-white/15 bg-[#080810] py-2 pl-9 pr-3 text-xs text-[#F5F3FF] placeholder:text-[#A6A3B8]/60 focus:border-[#873CFF] focus:outline-none"
          />
        </div>
      </div>

      {/* History Table */}
      <div className="sv-glass-panel overflow-hidden rounded-xl">
        {filteredRecords.length === 0 ? (
          <div className="px-6 py-14 text-center">
            <History className="mx-auto h-8 w-8 text-[#A6A3B8]/50" />
            <p className="mt-3 font-display text-sm font-semibold text-[#F5F3FF]">
              {records.length === 0
                ? 'No operations recorded yet'
                : 'No operations match your active filters'}
            </p>
            <p className="mt-1 text-xs text-[#A6A3B8]">
              {records.length === 0
                ? 'Encrypt or decrypt a file to generate audited history entries.'
                : 'Try resetting the operation or status filter to view all entries.'}
            </p>
            {(operationFilter !== 'all' || statusFilter !== 'all' || searchQuery) && (
              <button
                type="button"
                onClick={() => {
                  setOperationFilter('all');
                  setStatusFilter('all');
                  setSearchQuery('');
                }}
                className="mt-4 rounded-lg border border-white/15 bg-[#080810] px-3.5 py-1.5 text-xs font-medium text-[#F5F3FF] hover:bg-white/5"
              >
                Reset Filters
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-white/10 bg-[#080810]/70 text-xs font-medium text-[#A6A3B8]">
                  <th className="px-6 py-3">Filename</th>
                  <th className="px-4 py-3">Operation</th>
                  <th className="px-4 py-3">Date &amp; Time</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Output Filename</th>
                  <th className="px-4 py-3 text-right">Size</th>
                  <th className="px-6 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {filteredRecords.map((item) => (
                  <tr key={item.id} className="align-top transition-colors hover:bg-white/[0.03]">
                    <td className="px-6 py-3.5">
                      <p className="font-mono text-xs font-medium text-[#F5F3FF]">
                        {item.filename}
                      </p>
                      <p className="mt-0.5 max-w-sm text-xs text-[#A6A3B8]">
                        {item.message}
                      </p>
                    </td>
                    <td className="px-4 py-3.5 text-xs font-medium capitalize text-[#B69AFF] whitespace-nowrap">
                      {item.operation}
                    </td>
                    <td className="px-4 py-3.5 font-mono text-xs text-[#A6A3B8] tabular-nums whitespace-nowrap">
                      {formatTimestamp(item.timestamp)}
                    </td>
                    <td className="px-4 py-3.5 text-xs whitespace-nowrap">
                      {item.status === 'success' ? (
                        <span className="inline-flex items-center gap-1.5 font-medium text-[#27D99A]">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          Successful
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 font-medium text-rose-400">
                          <XCircle className="h-3.5 w-3.5" />
                          Failed
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3.5 font-mono text-xs text-[#F5F3FF]">
                      {item.outputFilename ?? '—'}
                    </td>
                    <td className="px-4 py-3.5 text-right font-mono text-xs text-[#A6A3B8] tabular-nums whitespace-nowrap">
                      {formatBytes(item.outputSizeBytes ?? item.inputSizeBytes)}
                    </td>
                    <td className="px-6 py-3.5 text-right whitespace-nowrap">
                      {item.status === 'success' && item.outputFilename ? (
                        <button
                          type="button"
                          onClick={() => handleDownloadOutput(item)}
                          className="inline-flex items-center gap-1 text-xs font-medium text-[#3478FF] hover:text-[#7CB0FF]"
                        >
                          <Download className="h-3.5 w-3.5" />
                          Download
                        </button>
                      ) : (
                        <span className="text-xs text-[#A6A3B8]/50">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
