import React from 'react';
import {
  ShieldCheck,
  KeyRound,
  FileCheck2,
  AlertTriangle,
  Lock,
  Unlock,
} from 'lucide-react';
import type { AppView } from '../types';

interface SecurityGuideViewProps {
  onNavigate: (view: AppView) => void;
}

export const SecurityGuideView: React.FC<SecurityGuideViewProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold tracking-tight text-[#F5F3FF]">
          Security Guide
        </h1>
        <p className="mt-1 text-sm text-[#A6A3B8]">
          Technical reference for Fernet symmetric cryptography, key custody practices, and safe
          file handling inside SecureVault.
        </p>
      </div>

      {/* Cryptographic Architecture */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="sv-glass-panel rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="h-5 w-5 text-[#873CFF]" />
            <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
              Authenticated Fernet Specification
            </h2>
          </div>
          <p className="text-sm leading-relaxed text-[#A6A3B8]">
            SecureVault implements the standard Fernet specification using{' '}
            <span className="text-[#F5F3FF]">AES-128 in CBC mode</span> with PKCS7 padding for
            confidentiality, paired with{' '}
            <span className="text-[#F5F3FF]">HMAC-SHA256</span> for message authentication. Every
            key is a 32-byte cryptographically random secret encoded as a 44-character URL-safe
            Base64 string.
          </p>
          <dl className="divide-y divide-white/10 border-t border-white/10 text-xs">
            <div className="flex items-center justify-between py-2.5">
              <dt className="text-[#A6A3B8]">Signing Subkey</dt>
              <dd className="font-mono text-[#F5F3FF]">Bytes 0–15 (128-bit HMAC-SHA256)</dd>
            </div>
            <div className="flex items-center justify-between py-2.5">
              <dt className="text-[#A6A3B8]">Encryption Subkey</dt>
              <dd className="font-mono text-[#F5F3FF]">Bytes 16–31 (128-bit AES-CBC)</dd>
            </div>
            <div className="flex items-center justify-between py-2.5">
              <dt className="text-[#A6A3B8]">Initialization Vector</dt>
              <dd className="font-mono text-[#F5F3FF]">Fresh 128-bit CSPRNG per file</dd>
            </div>
          </dl>
        </div>

        <div className="sv-glass-panel rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <FileCheck2 className="h-5 w-5 text-[#3478FF]" />
            <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
              File Processing &amp; Path Safety
            </h2>
          </div>
          <p className="text-sm leading-relaxed text-[#A6A3B8]">
            All input filenames are sanitized against directory traversal, path separators, and
            control characters. Output paths are strictly confined to designated vault folders, and
            duplicate output names are automatically versioned with timestamps so existing files are
            never silently overwritten.
          </p>
          <dl className="divide-y divide-white/10 border-t border-white/10 text-xs">
            <div className="flex items-center justify-between py-2.5">
              <dt className="text-[#A6A3B8]">Encryption Input</dt>
              <dd className="font-mono text-[#F5F3FF]">Non-empty .txt (up to 5 MB)</dd>
            </div>
            <div className="flex items-center justify-between py-2.5">
              <dt className="text-[#A6A3B8]">Decryption Input</dt>
              <dd className="font-mono text-[#F5F3FF]">Valid .enc Fernet token</dd>
            </div>
            <div className="flex items-center justify-between py-2.5">
              <dt className="text-[#A6A3B8]">Audit Logging Policy</dt>
              <dd className="font-mono text-[#27D99A]">Keys &amp; plaintext strictly omitted</dd>
            </div>
          </dl>
        </div>
      </section>

      {/* Key Custody & Error Handling */}
      <section className="sv-glass-panel rounded-xl p-6 space-y-5">
        <div className="flex items-center gap-2.5">
          <AlertTriangle className="h-5 w-5 text-amber-400" />
          <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
            Key Custody &amp; Recovery Rules
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3 text-xs leading-relaxed text-[#A6A3B8]">
          <div className="rounded-lg border border-white/10 bg-[#080810]/60 p-4">
            <p className="font-semibold text-[#F5F3FF]">1. Never Lose Your Key</p>
            <p className="mt-1.5">
              Fernet uses symmetric encryption with zero recovery backdoors. Download your{' '}
              <span className="font-mono text-[#F5F3FF]">.key</span> file immediately after
              generation and store an encrypted backup.
            </p>
          </div>
          <div className="rounded-lg border border-white/10 bg-[#080810]/60 p-4">
            <p className="font-semibold text-[#F5F3FF]">2. Separate Key &amp; Ciphertext</p>
            <p className="mt-1.5">
              Do not archive <span className="font-mono text-[#F5F3FF]">.key</span> files inside
              the same folder or cloud bucket as your{' '}
              <span className="font-mono text-[#F5F3FF]">.enc</span> artifacts.
            </p>
          </div>
          <div className="rounded-lg border border-white/10 bg-[#080810]/60 p-4">
            <p className="font-semibold text-[#F5F3FF]">3. Tamper Detection</p>
            <p className="mt-1.5">
              If even a single byte of an <span className="font-mono text-[#F5F3FF]">.enc</span>{' '}
              file is altered or the wrong key is used, constant-time HMAC verification rejects
              decryption immediately.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 border-t border-white/10 pt-4">
          <button
            type="button"
            onClick={() => onNavigate('keys')}
            className="inline-flex items-center gap-2 rounded-lg bg-[#27D99A]/15 border border-[#27D99A]/35 px-4 py-2 text-xs font-medium text-[#27D99A] hover:bg-[#27D99A]/25 whitespace-nowrap"
          >
            <KeyRound className="h-3.5 w-3.5" />
            Open Key Management
          </button>
          <button
            type="button"
            onClick={() => onNavigate('encrypt')}
            className="inline-flex items-center gap-2 rounded-lg bg-[#873CFF] px-4 py-2 text-xs font-medium text-white hover:bg-[#752CE8] whitespace-nowrap"
          >
            <Lock className="h-3.5 w-3.5" />
            Encrypt a Document
          </button>
          <button
            type="button"
            onClick={() => onNavigate('decrypt')}
            className="inline-flex items-center gap-2 rounded-lg border border-[#3478FF]/40 bg-[#3478FF]/15 px-4 py-2 text-xs font-medium text-[#7CB0FF] hover:bg-[#3478FF]/25 whitespace-nowrap"
          >
            <Unlock className="h-3.5 w-3.5" />
            Decrypt an Artifact
          </button>
        </div>
      </section>
    </div>
  );
};
