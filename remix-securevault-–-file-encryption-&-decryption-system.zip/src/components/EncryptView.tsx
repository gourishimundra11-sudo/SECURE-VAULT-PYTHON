import React, { useState } from 'react';
import {
  Lock,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Download,
  ArrowRight,
  Eye,
  EyeOff,
  FolderCheck,
  Loader2,
} from 'lucide-react';
import type { SelectedFileState, VaultFileSummary } from '../types';
import { FileDropzone } from './FileDropzone';
import { formatBytes, maskSecretKey } from '../utils/format';

interface EncryptResult {
  inputFilename: string;
  outputFilename: string;
  outputLocation: string;
  inputSizeBytes: number;
  outputSizeBytes: number;
  renamedDueToDuplicate: boolean;
  message: string;
  tokenPreview: string;
}

interface EncryptViewProps {
  sessionKey: string;
  onSetSessionKey: (key: string) => void;
  sampleFiles: VaultFileSummary[];
  onOperationComplete: () => void;
  onProceedToDecrypt: (encryptedFilename: string) => void;
  onNotify: (toast: { type: 'success' | 'error' | 'info'; title: string; description?: string }) => void;
}

export const EncryptView: React.FC<EncryptViewProps> = ({
  sessionKey,
  onSetSessionKey,
  sampleFiles,
  onOperationComplete,
  onProceedToDecrypt,
  onNotify,
}) => {
  const [selectedFile, setSelectedFile] = useState<SelectedFileState | null>(null);
  const [keyMode, setKeyMode] = useState<'session' | 'custom'>(sessionKey ? 'session' : 'custom');
  const [customKey, setCustomKey] = useState('');
  const [showCustomKey, setShowCustomKey] = useState(false);
  const [confirmOverwriteOpen, setConfirmOverwriteOpen] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<EncryptResult | null>(null);

  const activeKey = keyMode === 'session' ? sessionKey : customKey.trim();

  const handleGenerateInlineKey = async () => {
    if (sessionKey && !confirmOverwriteOpen) {
      setConfirmOverwriteOpen(true);
      return;
    }
    setConfirmOverwriteOpen(false);
    setError(null);
    try {
      const res = await fetch('/api/keys/generate', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to generate key.');
      onSetSessionKey(data.key);
      setKeyMode('session');
      onNotify({
        type: 'info',
        title: 'New Fernet key generated',
        description: 'Stored in session memory. Remember to back up your key in Key Management.',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to generate encryption key.';
      setError(msg);
      onNotify({ type: 'error', title: 'Key generation failed', description: msg });
    }
  };

  const handleKeyFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const text = (await file.text()).trim();
      setCustomKey(text);
      setKeyMode('custom');
      setError(null);
      onNotify({ type: 'info', title: 'Key file loaded', description: `Loaded ${file.name} for encryption.` });
    } catch {
      setError('Unable to read the selected .key file.');
    }
  };

  const handleEncrypt = async () => {
    setError(null);
    setResult(null);

    if (!selectedFile) {
      const msg = 'Missing file: please select or drop a .txt file before encrypting.';
      setError(msg);
      onNotify({ type: 'error', title: 'No file selected', description: msg });
      return;
    }
    if (!selectedFile.isValid) {
      setError(selectedFile.validationMessage);
      onNotify({ type: 'error', title: 'Invalid input file', description: selectedFile.validationMessage });
      return;
    }
    if (!activeKey) {
      const msg = 'Missing encryption key: generate a session key or paste/load an existing Fernet key.';
      setError(msg);
      onNotify({ type: 'error', title: 'Encryption key required', description: msg });
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/encrypt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: selectedFile.filename,
          vaultSampleName: selectedFile.source === 'vault' ? selectedFile.vaultName : undefined,
          contentBase64: selectedFile.source === 'upload' ? selectedFile.contentBase64 : undefined,
          key: activeKey,
        }),
      });
      const data = await res.json();
      onOperationComplete();

      if (!res.ok) {
        const msg = data.error || 'Encryption failed.';
        setError(msg);
        onNotify({ type: 'error', title: 'Encryption blocked', description: msg });
        return;
      }

      setResult(data as EncryptResult);
      onNotify({
        type: 'success',
        title: 'File encrypted successfully',
        description: `Saved as ${data.outputFilename}`,
      });
    } catch {
      const msg = 'Network or server error while encrypting the file. Please try again.';
      setError(msg);
      onNotify({ type: 'error', title: 'Connection error', description: msg });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDownloadOutput = () => {
    if (!result) return;
    window.location.assign(
      `/api/vault/download?category=encrypted&filename=${encodeURIComponent(result.outputFilename)}`
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold tracking-tight text-[#F5F3FF]">
          Encrypt Plain-Text File
        </h1>
        <p className="mt-1 text-sm text-[#A6A3B8]">
          Select a <span className="font-mono text-xs text-[#F5F3FF]">.txt</span> document and
          encrypt it with a Fernet key. Output artifacts are saved with a{' '}
          <span className="font-mono text-xs text-[#F5F3FF]">.enc</span> extension.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 items-start">
        <div className="space-y-6 lg:col-span-7">
          <div className="sv-glass-panel rounded-xl p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
                01. Select Input Document
              </h2>
              <span className="font-mono text-xs text-[#B69AFF]">Format: .txt</span>
            </div>
            <FileDropzone
              mode="encrypt"
              selectedFile={selectedFile}
              onSelectFile={(f) => {
                setSelectedFile(f);
                setResult(null);
                setError(null);
              }}
              vaultFiles={sampleFiles}
            />
          </div>

          <div className="sv-glass-panel rounded-xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
                02. Encryption Key
              </h2>
              <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-[#080810] p-1">
                <button
                  type="button"
                  onClick={() => setKeyMode('session')}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                    keyMode === 'session'
                      ? 'bg-[#873CFF] text-white'
                      : 'text-[#A6A3B8] hover:text-[#F5F3FF]'
                  }`}
                >
                  Session Key
                </button>
                <button
                  type="button"
                  onClick={() => setKeyMode('custom')}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                    keyMode === 'custom'
                      ? 'bg-[#3478FF] text-white'
                      : 'text-[#A6A3B8] hover:text-[#F5F3FF]'
                  }`}
                >
                  Load Key
                </button>
              </div>
            </div>

            {keyMode === 'session' ? (
              <div className="space-y-3">
                {sessionKey ? (
                  <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#27D99A]/25 bg-[#080810]/70 px-4 py-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <KeyRound className="h-4 w-4 shrink-0 text-[#27D99A]" />
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-[#F5F3FF]">
                          Active Fernet key loaded in memory
                        </p>
                        <p className="truncate font-mono text-xs text-[#A6A3B8]">
                          {maskSecretKey(sessionKey)}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleGenerateInlineKey}
                      className="rounded-lg border border-white/15 bg-[#11111D] px-3 py-1.5 text-xs font-medium text-[#F5F3FF] hover:border-[#B69AFF]/45 hover:bg-white/5 whitespace-nowrap shrink-0"
                    >
                      Rotate Key
                    </button>
                  </div>
                ) : (
                  <div className="rounded-xl border border-white/10 bg-[#080810]/60 px-4 py-4">
                    <p className="text-sm text-[#F5F3FF]">
                      No encryption key is currently loaded in this session.
                    </p>
                    <p className="mt-1 text-xs text-[#A6A3B8]">
                      Generate a new 32-byte Fernet key now, or switch to Load Key to provide an existing key.
                    </p>
                    <button
                      type="button"
                      onClick={handleGenerateInlineKey}
                      className="mt-3 inline-flex items-center gap-2 rounded-lg bg-[#873CFF] px-3.5 py-2 text-xs font-medium text-white hover:bg-[#752CE8] whitespace-nowrap"
                    >
                      <KeyRound className="h-3.5 w-3.5" />
                      Generate New Key
                    </button>
                  </div>
                )}

                {confirmOverwriteOpen && (
                  <div className="rounded-xl border border-amber-400/35 bg-amber-950/30 p-3.5 text-xs text-amber-100">
                    <p className="font-semibold text-amber-300">Replace active session key?</p>
                    <p className="mt-1 leading-relaxed text-amber-200/90">
                      Generating a new key will replace the key currently held in memory. Back up
                      your existing key first if you still need it to decrypt earlier files.
                    </p>
                    <div className="mt-3 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleGenerateInlineKey}
                        className="rounded-md bg-amber-500 px-3 py-1.5 font-medium text-[#080810] hover:bg-amber-400 whitespace-nowrap"
                      >
                        Confirm New Key
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmOverwriteOpen(false)}
                        className="rounded-md border border-amber-400/30 bg-[#11111D] px-3 py-1.5 font-medium text-amber-200 hover:bg-white/5 whitespace-nowrap"
                      >
                        Keep Current Key
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <label htmlFor="encrypt-key-input" className="text-xs font-medium text-[#F5F3FF]">
                    Fernet Encryption Key (URL-safe Base64)
                  </label>
                  <label className="cursor-pointer text-xs font-medium text-[#7CB0FF] hover:text-[#B69AFF]">
                    Load .key file
                    <input
                      type="file"
                      accept=".key,.txt"
                      onChange={handleKeyFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                <div className="relative">
                  <input
                    id="encrypt-key-input"
                    type={showCustomKey ? 'text' : 'password'}
                    value={customKey}
                    onChange={(e) => setCustomKey(e.target.value)}
                    placeholder="Paste 44-character Fernet key..."
                    autoComplete="off"
                    spellCheck={false}
                    className="w-full rounded-lg border border-white/15 bg-[#080810] py-2.5 pl-3 pr-10 font-mono text-xs text-[#F5F3FF] placeholder:text-[#A6A3B8]/55 focus:border-[#873CFF] focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCustomKey((v) => !v)}
                    aria-label={showCustomKey ? 'Hide key' : 'Show key'}
                    className="absolute inset-y-0 right-0 flex items-center px-3 text-[#A6A3B8] hover:text-[#F5F3FF]"
                  >
                    {showCustomKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                <p className="text-xs text-[#A6A3B8]">
                  Keys are processed strictly in memory and are never written to logs or activity history.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Right: Execution & Output */}
        <div className="space-y-6 lg:col-span-5">
          <div className="sv-glass-panel rounded-xl p-6 space-y-5">
            <div>
              <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
                03. Execute Encryption
              </h2>
              <p className="mt-1 text-xs text-[#A6A3B8]">
                Verify your selected document and key before sealing the output artifact.
              </p>
            </div>

            <dl className="divide-y divide-white/10 border-y border-white/10 text-xs">
              <div className="flex items-center justify-between py-2.5">
                <dt className="text-[#A6A3B8]">Selected File</dt>
                <dd className="max-w-[210px] truncate font-mono font-medium text-[#F5F3FF]">
                  {selectedFile ? selectedFile.filename : 'None'}
                </dd>
              </div>
              <div className="flex items-center justify-between py-2.5">
                <dt className="text-[#A6A3B8]">File Format</dt>
                <dd className="font-mono text-[#F5F3FF]">
                  {selectedFile ? selectedFile.mimeType : '—'}
                </dd>
              </div>
              <div className="flex items-center justify-between py-2.5">
                <dt className="text-[#A6A3B8]">Encryption Key</dt>
                <dd className="font-medium text-[#F5F3FF]">
                  {activeKey ? 'Ready (Hidden)' : 'Not provided'}
                </dd>
              </div>
              <div className="flex items-center justify-between py-2.5">
                <dt className="text-[#A6A3B8]">Output Format</dt>
                <dd className="font-mono text-[#B69AFF]">.enc (Fernet Token)</dd>
              </div>
            </dl>

            <button
              type="button"
              onClick={handleEncrypt}
              disabled={submitting}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#873CFF] to-[#3478FF] px-4 py-2.5 text-sm font-medium text-white transition-opacity hover:opacity-95 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Encrypting File...
                </>
              ) : (
                <>
                  <Lock className="h-4 w-4" />
                  Encrypt Now
                </>
              )}
            </button>

            {error && (
              <div className="flex items-start gap-2.5 rounded-lg border border-rose-500/35 bg-rose-950/30 p-3.5 text-xs leading-relaxed text-rose-200">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            {result && (
              <div className="space-y-4 rounded-xl border border-[#27D99A]/35 bg-[#27D99A]/10 p-4">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#27D99A]" />
                  <div>
                    <p className="text-sm font-semibold text-[#F5F3FF]">
                      Operation Status: Encrypted
                    </p>
                    <p className="mt-0.5 text-xs text-[#A6A3B8]">{result.message}</p>
                  </div>
                </div>

                <dl className="space-y-2 border-t border-white/10 pt-3 text-xs">
                  <div className="flex items-start justify-between gap-2">
                    <dt className="shrink-0 text-[#A6A3B8]">Output File</dt>
                    <dd className="break-all text-right font-mono font-medium text-[#F5F3FF]">
                      {result.outputFilename}
                    </dd>
                  </div>
                  <div className="flex items-start justify-between gap-2">
                    <dt className="shrink-0 text-[#A6A3B8]">Saved Location</dt>
                    <dd className="inline-flex items-center gap-1 break-all text-right font-mono text-[#27D99A]">
                      <FolderCheck className="h-3.5 w-3.5 shrink-0" />
                      {result.outputLocation}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-[#A6A3B8]">Size Change</dt>
                    <dd className="font-mono text-[#F5F3FF] tabular-nums">
                      {formatBytes(result.inputSizeBytes)} → {formatBytes(result.outputSizeBytes)}
                    </dd>
                  </div>
                </dl>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleDownloadOutput}
                    className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-[#27D99A] px-3 py-2 text-xs font-semibold text-[#080810] hover:bg-[#22C58B] whitespace-nowrap"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Download Encrypted File
                  </button>
                  <button
                    type="button"
                    onClick={() => onProceedToDecrypt(result.outputFilename)}
                    className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-white/15 bg-[#11111D] px-3 py-2 text-xs font-medium text-[#F5F3FF] hover:border-[#3478FF]/50 hover:bg-white/5 whitespace-nowrap"
                  >
                    Test Decrypt
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
