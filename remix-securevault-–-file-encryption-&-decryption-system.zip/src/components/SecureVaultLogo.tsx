import React, { useId } from 'react';

interface SecureVaultLogoProps {
  variant?: 'full' | 'sidebar' | 'header' | 'icon';
  className?: string;
}

export const SecureVaultLogo: React.FC<SecureVaultLogoProps> = ({
  variant = 'full',
  className = '',
}) => {
  const uid = useId().replace(/:/g, '');
  const shieldGradId = `sv-shield-${uid}`;
  const orbitGradId = `sv-orbit-${uid}`;
  const coreGradId = `sv-core-${uid}`;

  const iconSize =
    variant === 'header'
      ? 'h-7 w-7'
      : variant === 'sidebar'
        ? 'h-9 w-9'
        : variant === 'icon'
          ? 'h-8 w-8'
          : 'h-10 w-10';

  const mark = (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${iconSize} shrink-0`}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={shieldGradId} x1="12" y1="8" x2="52" y2="56" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#873CFF" />
          <stop offset="55%" stopColor="#B69AFF" />
          <stop offset="100%" stopColor="#3478FF" />
        </linearGradient>
        <linearGradient id={orbitGradId} x1="6" y1="20" x2="58" y2="44" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#B69AFF" stopOpacity="0.95" />
          <stop offset="100%" stopColor="#3478FF" stopOpacity="0.7" />
        </linearGradient>
        <linearGradient id={coreGradId} x1="23" y1="29" x2="41" y2="42" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#873CFF" stopOpacity="0.34" />
          <stop offset="100%" stopColor="#3478FF" stopOpacity="0.24" />
        </linearGradient>
      </defs>

      {/* Circular protection orbit ring */}
      <ellipse
        cx="32"
        cy="33"
        rx="27"
        ry="11"
        transform="rotate(-18 32 33)"
        stroke={`url(#${orbitGradId})`}
        strokeWidth="1.7"
        strokeDasharray="4 3"
      />

      {/* Geometric faceted shield */}
      <path
        d="M32 9.5L50.5 17.2V31.5C50.5 43.4 42.6 51.9 32 55.4C21.4 51.9 13.5 43.4 13.5 31.5V17.2L32 9.5Z"
        fill="#11111D"
        stroke={`url(#${shieldGradId})`}
        strokeWidth="2.4"
        strokeLinejoin="round"
      />

      {/* Padlock shackle */}
      <path
        d="M26 29V25.5C26 22.1863 28.6863 19.5 32 19.5C35.3137 19.5 38 22.1863 38 25.5V29"
        stroke="#B69AFF"
        strokeWidth="2.3"
        strokeLinecap="round"
      />

      {/* Padlock body */}
      <rect
        x="23"
        y="29"
        width="18"
        height="13"
        rx="3"
        fill={`url(#${coreGradId})`}
        stroke="#B69AFF"
        strokeWidth="1.9"
      />

      {/* Keyhole */}
      <circle cx="32" cy="34.6" r="1.9" fill="#F5F3FF" />
      <path d="M32 36.4V38.9" stroke="#F5F3FF" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );

  if (variant === 'icon') {
    return <span className={`inline-flex items-center justify-center ${className}`}>{mark}</span>;
  }

  return (
    <span className={`inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 ${className}`}>
      {mark}
      <span
        className={`font-display font-bold tracking-tight text-[#F5F3FF] ${
          variant === 'header' ? 'text-base' : variant === 'sidebar' ? 'text-lg' : 'text-xl'
        }`}
      >
        SecureVault
      </span>
    </span>
  );
};
