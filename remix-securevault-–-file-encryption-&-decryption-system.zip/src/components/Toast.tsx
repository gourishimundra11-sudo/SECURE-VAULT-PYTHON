import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import type { ToastNotification } from '../types';

interface ToastContainerProps {
  toasts: ToastNotification[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  return (
    <div
      aria-live="polite"
      className="pointer-events-none fixed bottom-5 right-5 z-50 flex w-full max-w-sm flex-col gap-2.5 px-4 sm:px-0"
    >
      <AnimatePresence initial={false}>
        {toasts.map((toast) => {
          const borderClass =
            toast.type === 'success'
              ? 'border-[#27D99A]/35'
              : toast.type === 'error'
                ? 'border-rose-500/40'
                : 'border-[#B69AFF]/35';

          return (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 14, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.98 }}
              transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
              className={`pointer-events-auto sv-glass-panel rounded-xl border ${borderClass} p-3.5 shadow-xl shadow-black/50`}
            >
              <div className="flex items-start gap-3">
                {toast.type === 'success' && (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#27D99A]" />
                )}
                {toast.type === 'error' && (
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
                )}
                {toast.type === 'info' && (
                  <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#B69AFF]" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold text-[#F5F3FF]">{toast.title}</p>
                  {toast.description && (
                    <p className="mt-0.5 text-xs leading-relaxed text-[#A6A3B8]">
                      {toast.description}
                    </p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => onDismiss(toast.id)}
                  aria-label="Dismiss notification"
                  className="rounded p-1 text-[#A6A3B8] transition-colors hover:bg-white/5 hover:text-[#F5F3FF]"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
