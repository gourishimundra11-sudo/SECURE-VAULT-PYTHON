import React, { useState } from 'react';
import {
  KeyRound,
  Download,
  Upload,
  Eye,
  EyeOff,
  Copy,
  Check,
  AlertTriangle,
  ShieldAlert,
  FolderPlus,
  Trash2,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { downloadTextFile, maskSecretKey } from '../utils/format';

interface KeyManagementViewProps {
  sessionKey: string;
  onSetSessionKey: (key: string) => void;
  onClearSessionKey: () => void;
  onNotify: (toast: { type: 'success' | 'error' | 'info'; title: string; description?: string }) => void;
}

export const KeyManagementView: React.FC<KeyManagementViewProps> = ({
  sessionKey,
  onSetSessionKey,
  onClearSessionKey,
  onNotify,
}) => {
  const [revealKey, setRevealKey] = useState(false);
  const [copied, setCopied] = useState(false);
  const [loadInput, setLoadInput] = useState('');
  const [showLoadInput, setShowLoadInput] = useState(false);
  const [vaultKeyFilename, setVaultKeyFilename] = useState('securevault_master.key');

  const [pendingAction, setPendingAction] = useState<
    | { type: 'generate' }
    | { type: 'load'; key: string }
    | null
  >(null);

  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );

  const executeGenerateKey = async (force: boolean) => {
    if (sessionKey && !force) {
      setPendingAction({ type: 'generate' });
      return;
    }
    setPendingAction(null);
    setBusy(true);
    setFeedback(null);
    try {
      const res = await fetch('/api/keys/generate', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to generate key.');
      onSetSessionKey(data.key);
      setRevealKey(false);
      const msg =
        'Generated a new 32-byte Fernet key in session memory. Download or back up your key before ending this session.';
      setFeedback({ type: 'success', text: msg });
      onNotify({ type: 'success', title: 'New Fernet key generated', description: 'Held securely in session memory.' });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to generate key.';
      setFeedback({ type: 'error', text: msg });
      onNotify({ type: 'error', title: 'Key generation failed', description: msg });
    } finally {
      setBusy(false);
    }
  };

  const executeLoadKey = async (candidateKey: string, force: boolean) => {
    const trimmed = candidateKey.trim();
    if (!trimmed) {
      setFeedback({ type: 'error', text: 'Please enter or upload a Fernet key to load.' });
      return;
    }

    setBusy(true);
    setFeedback(null);
    try {
      const res = await fetch('/api/keys/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: trimmed }),
      });
      const data = await res.json();
      if (!res.ok || !data.valid) {
        const msg = data.error || 'Invalid Fernet key format.';
        setFeedback({ type: 'error', text: msg });
        onNotify({ type: 'error', title: 'Invalid Fernet key', description: msg });
        return;
      }

      if (sessionKey && sessionKey !== trimmed && !force) {
        setPendingAction({ type: 'load', key: trimmed });
        return;
      }

      setPendingAction(null);
      onSetSessionKey(trimmed);
      setLoadInput('');
      setRevealKey(false);
      setFeedback({
        type: 'success',
        text: 'Fernet key validated and loaded into session memory.',
      });
      onNotify({ type: 'success', title: 'Encryption key loaded', description: 'Validated and active in memory.' });
    } catch {
      setFeedback({ type: 'error', text: 'Unable to validate the provided key.' });
    } finally {
      setBusy(false);
    }
  };

  const handleKeyFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const text = (await file.text()).trim();
      await executeLoadKey(text, false);
    } catch {
      setFeedback({ type: 'error', text: 'Failed to read the selected .key file.' });
    }
  };

  const handleCopyKey = async () => {
    if (!sessionKey) return;
    try {
      await navigator.clipboard.writeText(sessionKey);
      setCopied(true);
      onNotify({ type: 'info', title: 'Key copied to clipboard' });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setFeedback({
        type: 'error',
        text: 'Clipboard access was denied. Use the Download .key button instead.',
      });
    }
  };

  const handleDownloadKey = () => {
    if (!sessionKey) return;
    const stamp = new Date().toISOString().slice(0, 10);
    downloadTextFile(`securevault_${stamp}.key`, `${sessionKey}\n`);
    onNotify({ type: 'success', title: 'Key exported', description: `Downloaded securevault_${stamp}.key` });
  };

  const handleSaveKeyToVault = async () => {
    if (!sessionKey) return;
    setBusy(true);
    setFeedback(null);
    try {
      const res = await fetch('/api/keys/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: sessionKey, filename: vaultKeyFilename }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save key file.');
      const msg = data.renamedDueToDuplicate
        ? `Existing key preserved. Saved new key file to ${data.savedLocation}.`
        : `Key file saved to ${data.savedLocation}.`;
      setFeedback({ type: 'success', text: msg });
      onNotify({ type: 'success', title: 'Key saved to vault', description: data.savedLocation });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to save key file to vault.';
      setFeedback({ type: 'error', text: msg });
      onNotify({ type: 'error', title: 'Save failed', description: msg });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold tracking-tight text-[#F5F3FF]">
          Encryption Key Management
        </h1>
        <p className="mt-1 text-sm text-[#A6A3B8]">
          Generate, validate, load, and export 32-byte Fernet symmetric keys. Keys remain in memory
          for your active session and are never written to logs or activity history.
        </p>
      </div>

      {feedback && (
        <div
          className={`flex items-start gap-2.5 rounded-xl border px-4 py-3 text-sm ${
            feedback.type === 'success'
              ? 'border-[#27D99A]/35 bg-[#27D99A]/10 text-[#F5F3FF]'
              : 'border-rose-500/35 bg-rose-950/30 text-rose-200'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#27D99A]" />
          ) : (
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {pendingAction && (
        <div className="rounded-xl border border-amber-400/35 bg-amber-950/30 p-5">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
            <div className="space-y-3">
              <div>
                <h2 className="font-display text-sm font-semibold text-amber-200">
                  Confirm Replacing Active Session Key
                </h2>
                <p className="mt-1 text-xs leading-relaxed text-amber-100/85">
                  An encryption key is already loaded in your session. SecureVault never silently
                  overwrites an existing key. If you replace it before backing it up, files
                  encrypted with the previous key cannot be decrypted without that backup.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={() =>
                    pendingAction.type === 'generate'
                      ? executeGenerateKey(true)
                      : executeLoadKey(pendingAction.key, true)
                  }
                  className="rounded-lg bg-amber-400 px-3.5 py-2 text-xs font-semibold text-[#080810] hover:bg-amber-300 whitespace-nowrap"
                >
                  Replace Session Key
                </button>
                <button
                  type="button"
                  onClick={() => setPendingAction(null)}
                  className="rounded-lg border border-amber-400/30 bg-[#11111D] px-3.5 py-2 text-xs font-medium text-amber-200 hover:bg-white/5 whitespace-nowrap"
                >
                  Cancel &amp; Keep Existing Key
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Active Session Key Panel */}
      <section className="sv-glass-panel rounded-xl p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
              Active Session Key
            </h2>
            <p className="mt-1 text-xs text-[#A6A3B8]">
              Algorithm: Fernet (128-bit AES-CBC encryption key + 128-bit HMAC-SHA256 signing key)
            </p>
          </div>
          <button
            type="button"
            disabled={busy}
            onClick={() => executeGenerateKey(false)}
            className="inline-flex items-center gap-2 rounded-lg bg-[#873CFF] px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-[#752CE8] disabled:opacity-60 whitespace-nowrap shrink-0"
          >
            <KeyRound className="h-4 w-4" />
            Generate New Key
          </button>
        </div>

        {sessionKey ? (
          <div className="mt-5 space-y-4 border-t border-white/10 pt-5">
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-[#080810] px-4 py-3">
              <code className="break-all font-mono text-xs text-[#B69AFF]">
                {revealKey ? sessionKey : maskSecretKey(sessionKey)}
              </code>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setRevealKey((v) => !v)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#11111D] px-2.5 py-1.5 text-xs font-medium text-[#F5F3FF] hover:border-[#B69AFF]/45 hover:bg-white/5 whitespace-nowrap"
                >
                  {revealKey ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                  {revealKey ? 'Hide' : 'Reveal'}
                </button>
                <button
                  type="button"
                  onClick={handleCopyKey}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#11111D] px-2.5 py-1.5 text-xs font-medium text-[#F5F3FF] hover:border-[#B69AFF]/45 hover:bg-white/5 whitespace-nowrap"
                >
                  {copied ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-[#27D99A]" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      Copy
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleDownloadKey}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#27D99A] px-3.5 py-2 text-xs font-semibold text-[#080810] hover:bg-[#22C58B] whitespace-nowrap"
                >
                  <Download className="h-3.5 w-3.5" />
                  Download .key File
                </button>

                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    value={vaultKeyFilename}
                    onChange={(e) => setVaultKeyFilename(e.target.value)}
                    aria-label="Vault key filename"
                    className="w-48 rounded-lg border border-white/15 bg-[#080810] px-2.5 py-1.5 font-mono text-xs text-[#F5F3FF] focus:border-[#873CFF] focus:outline-none"
                  />
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleSaveKeyToVault}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#11111D] px-3.5 py-2 text-xs font-medium text-[#F5F3FF] hover:border-[#B69AFF]/45 hover:bg-white/5 whitespace-nowrap"
                  >
                    <FolderPlus className="h-3.5 w-3.5 text-[#B69AFF]" />
                    Save Key to Vault
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  onClearSessionKey();
                  setRevealKey(false);
                  onNotify({ type: 'info', title: 'Session key cleared from memory' });
                }}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-400 hover:text-rose-300 whitespace-nowrap"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Clear from Session
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-5 rounded-xl border border-dashed border-white/15 bg-[#080810]/60 px-5 py-6 text-center">
            <p className="text-sm font-medium text-[#F5F3FF]">No encryption key loaded</p>
            <p className="mt-1 text-xs text-[#A6A3B8]">
              Click Generate New Key above or load an existing .key file below to begin encrypting or decrypting files.
            </p>
          </div>
        )}
      </section>

      {/* Load Existing Key & Security Rules */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="sv-glass-panel rounded-xl p-6 space-y-4">
          <div>
            <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
              Load Existing Key
            </h2>
            <p className="mt-1 text-xs text-[#A6A3B8]">
              Import a saved <span className="font-mono text-[#F5F3FF]">.key</span> file or paste a
              valid URL-safe Base64 Fernet key to load it into session memory.
            </p>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label htmlFor="load-existing-key" className="text-xs font-medium text-[#F5F3FF]">
                Fernet Key String
              </label>
              <label className="inline-flex cursor-pointer items-center gap-1.5 text-xs font-medium text-[#7CB0FF] hover:text-[#B69AFF]">
                <Upload className="h-3.5 w-3.5" />
                Upload .key File
                <input
                  type="file"
                  accept=".key,.txt"
                  onChange={handleKeyFileSelect}
                  className="hidden"
                />
              </label>
            </div>

            <div className="relative">
              <input
                id="load-existing-key"
                type={showLoadInput ? 'text' : 'password'}
                value={loadInput}
                onChange={(e) => setLoadInput(e.target.value)}
                placeholder="Paste 44-character Fernet key..."
                autoComplete="off"
                spellCheck={false}
                className="w-full rounded-lg border border-white/15 bg-[#080810] py-2.5 pl-3 pr-10 font-mono text-xs text-[#F5F3FF] placeholder:text-[#A6A3B8]/55 focus:border-[#3478FF] focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowLoadInput((v) => !v)}
                aria-label={showLoadInput ? 'Hide key' : 'Show key'}
                className="absolute inset-y-0 right-0 flex items-center px-3 text-[#A6A3B8] hover:text-[#F5F3FF]"
              >
                {showLoadInput ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>

            <button
              type="button"
              disabled={busy}
              onClick={() => executeLoadKey(loadInput, false)}
              className="inline-flex items-center gap-2 rounded-lg bg-[#3478FF] px-4 py-2 text-xs font-medium text-white hover:bg-[#2563EB] disabled:opacity-60 whitespace-nowrap"
            >
              Validate &amp; Load Key
            </button>
          </div>
        </section>

        <section className="sv-glass-panel rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-amber-400" />
            <h2 className="font-display text-base font-semibold text-[#F5F3FF]">
              Key Security &amp; Backup Reminders
            </h2>
          </div>

          <div className="divide-y divide-white/10 text-xs leading-relaxed text-[#A6A3B8]">
            <div className="pb-3">
              <p className="font-semibold text-[#F5F3FF]">
                Permanent Loss Warning (No Recovery)
              </p>
              <p className="mt-1">
                Fernet encryption is strictly symmetric with zero backdoors. If you lose or delete
                your encryption key, encrypted <span className="font-mono text-[#F5F3FF]">.enc</span>{' '}
                files cannot be decrypted or recovered.
              </p>
            </div>

            <div className="py-3">
              <p className="font-semibold text-[#F5F3FF]">
                Never Share Encryption Keys
              </p>
              <p className="mt-1">
                Anyone holding both your <span className="font-mono text-[#F5F3FF]">.enc</span> file
                and its key can read and forge data. Never send keys over unencrypted chat or email,
                and never commit <span className="font-mono text-[#F5F3FF]">.key</span> files to
                repositories.
              </p>
            </div>

            <div className="pt-3">
              <p className="font-semibold text-[#F5F3FF]">
                Recommended Storage Instructions
              </p>
              <p className="mt-1">
                Download your <span className="font-mono text-[#F5F3FF]">.key</span> file and store
                it inside an encrypted password manager or offline hardware drive, separate from
                your encrypted <span className="font-mono text-[#F5F3FF]">.enc</span> archives.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
