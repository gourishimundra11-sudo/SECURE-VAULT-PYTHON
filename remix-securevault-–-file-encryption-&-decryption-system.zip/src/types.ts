export type AppView =
  | 'dashboard'
  | 'encrypt'
  | 'decrypt'
  | 'keys'
  | 'history'
  | 'guide';

export type OperationType = 'encrypt' | 'decrypt';
export type OperationStatus = 'success' | 'failed';

export interface ActivityRecord {
  id: string;
  filename: string;
  operation: OperationType;
  timestamp: string;
  status: OperationStatus;
  outputFilename: string | null;
  outputLocation: string | null;
  inputSizeBytes: number;
  outputSizeBytes: number | null;
  message: string;
}

export interface VaultFileSummary {
  filename: string;
  category: 'samples' | 'encrypted' | 'decrypted' | 'keys';
  sizeBytes: number;
  updatedAt: string;
  relativePath: string;
}

export interface DashboardData {
  stats: {
    totalProcessed: number;
    successfulEncryptions: number;
    successfulDecryptions: number;
    failedOperations: number;
  };
  recentActivity: ActivityRecord[];
  vaultFiles: {
    samples: VaultFileSummary[];
    encrypted: VaultFileSummary[];
    decrypted: VaultFileSummary[];
  };
}

export interface SelectedFileState {
  source: 'upload' | 'vault';
  filename: string;
  sizeBytes: number;
  mimeType: string;
  contentBase64?: string;
  vaultName?: string;
  isValid: boolean;
  validationMessage: string;
}

export interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  description?: string;
}
