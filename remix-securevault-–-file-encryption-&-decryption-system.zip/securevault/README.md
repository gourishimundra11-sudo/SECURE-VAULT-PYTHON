# SecureVault – File Encryption & Decryption System

SecureVault is a Python cybersecurity web application built with **Flask**, **`cryptography` (Fernet)**, and **SQLite** for encrypting `.txt` documents, verifying and decrypting `.enc` files, managing symmetric keys safely in session memory, and auditing operations without ever logging secrets.

## Project Structure

```text
securevault/
├── app.py
├── config.py
├── requirements.txt
├── .env.example
├── core/
│   ├── __init__.py
│   ├── encryption.py      # EncryptionManager & encrypt_file()
│   ├── decryption.py      # DecryptionManager & decrypt_file()
│   ├── key_manager.py     # KeyManager & generate_key()
│   ├── file_handler.py    # FileHandler & validate_file()
│   └── history.py         # HistoryManager (SQLite), save_operation(), get_operation_history()
├── templates/
│   ├── base.html
│   ├── dashboard.html
│   ├── encrypt.html
│   ├── decrypt.html
│   ├── keys.html
│   ├── history.html
│   └── guide.html
├── static/
│   ├── css/style.css
│   ├── js/script.js
│   └── images/logo.svg
├── storage/               # Private vault storage & SQLite DB
├── logs/                  # Rotating audit logs (never logs keys or plaintext)
└── tests/
    └── test_encryption.py
```

## Local Installation & Execution

Requires **Python 3.11+**.

```bash
cd securevault
python -m venv venv
```

Activate the virtual environment:

- **Linux / macOS:** `source venv/bin/activate`
- **Windows (PowerShell):** `venv\Scripts\Activate.ps1`

Install dependencies and launch the application:

```bash
pip install -r requirements.txt
cp .env.example .env
python app.py
```

Open your browser at:

```text
http://127.0.0.1:5000/
```

## Running the Test Suite

```bash
python -m unittest discover -s tests -v
```

Or with pytest:

```bash
pytest -v
```

## Security Design Highlights

- **Standard Fernet Cryptography:** Uses `cryptography.fernet.Fernet` (`AES-128-CBC` + PKCS7 padding + `HMAC-SHA256`).
- **Zero Secret Logging:** Encryption keys and file plaintext are never written to `logs/securevault.log` or `storage/securevault.db`.
- **Path Confinement & Safe Naming:** Filenames are sanitized against traversal (`..`, `/`, `\`) and collisions append timestamps so existing files are never overwritten.
- **CSRF & Safe Downloads:** All `POST` forms validate session-bound CSRF tokens via `hmac.compare_digest`, and `/download/<category>/<filename>` restricts downloads to `encrypted` and `decrypted` folders with `X-Content-Type-Options: nosniff`.
