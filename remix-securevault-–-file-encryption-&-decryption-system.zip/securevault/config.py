"""Central configuration and audit logging setup for SecureVault."""

import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import secrets


BASE_DIR = Path(__file__).resolve().parent


class Config:
    """Application configuration with secure defaults and confined paths."""

    SECRET_KEY: str = os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32)
    DEBUG: bool = os.environ.get("FLASK_DEBUG", "false").lower() == "true"

    MAX_UPLOAD_MB: int = int(os.environ.get("MAX_UPLOAD_MB", "5"))
    MAX_CONTENT_LENGTH: int = MAX_UPLOAD_MB * 1024 * 1024

    STORAGE_DIR: Path = BASE_DIR / "storage"
    UPLOADS_DIR: Path = STORAGE_DIR / "uploads"
    ENCRYPTED_DIR: Path = STORAGE_DIR / "encrypted"
    DECRYPTED_DIR: Path = STORAGE_DIR / "decrypted"
    SAMPLES_DIR: Path = STORAGE_DIR / "samples"
    DATABASE_PATH: Path = STORAGE_DIR / "securevault.db"

    LOGS_DIR: Path = BASE_DIR / "logs"
    LOG_FILE: Path = LOGS_DIR / "securevault.log"

    ALLOWED_ENCRYPT_EXTENSIONS: set[str] = {".txt"}
    ALLOWED_DECRYPT_EXTENSIONS: set[str] = {".enc"}

    SESSION_COOKIE_HTTPONLY: bool = True
    SESSION_COOKIE_SAMESITE: str = "Lax"

    @classmethod
    def ensure_directories(cls) -> None:
        """Create private vault directories with restricted permissions."""
        for directory in (
            cls.STORAGE_DIR,
            cls.UPLOADS_DIR,
            cls.ENCRYPTED_DIR,
            cls.DECRYPTED_DIR,
            cls.SAMPLES_DIR,
            cls.LOGS_DIR,
        ):
            directory.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(directory, 0o700)
            except OSError:
                # Some filesystems (e.g., Windows) may ignore POSIX chmod bits.
                pass


def configure_logging(log_file: Path) -> logging.Logger:
    """Configure application logger. Never records encryption keys or plaintext."""
    log_file.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("securevault")
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = RotatingFileHandler(
        log_file, maxBytes=1_048_576, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    return logger
