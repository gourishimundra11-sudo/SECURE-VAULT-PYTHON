"""SecureVault Flask application entry point."""

from datetime import datetime, timezone
import hmac
from pathlib import Path
import secrets

from flask import (
    Flask,
    Response,
    abort,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)

from config import Config, configure_logging
from core.decryption import DecryptionError, DecryptionManager
from core.encryption import EncryptionError, EncryptionManager
from core.file_handler import FileHandler, FileValidationError
from core.history import HistoryManager
from core.key_manager import KeyManagementError, KeyManager


def _seed_sample_files(samples_dir: Path) -> None:
    """Create initial sample .txt files for academic demonstration if none exist."""
    if any(p.is_file() for p in samples_dir.iterdir()):
        return

    (samples_dir / "research_notes.txt").write_text(
        "\n".join(
            [
                "SecureVault Academic Cryptography Sample",
                "Algorithm: Fernet Symmetric Encryption (AES-128-CBC + HMAC-SHA256)",
                "",
                "This sample document demonstrates end-to-end encryption, integrity",
                "verification, and safe file recovery using Python cryptography.",
            ]
        ),
        encoding="utf-8",
    )
    (samples_dir / "incident_response_memo.txt").write_text(
        "\n".join(
            [
                "Incident Review Summary",
                "Reference: SEC-2026-0419",
                "",
                "All archival logs must be encrypted prior to external backup.",
                "Never store symmetric keys in application logs or databases.",
            ]
        ),
        encoding="utf-8",
    )


def _strip_enc_extension(filename: str) -> str:
    if filename.lower().endswith(".enc"):
        stem = filename[:-4]
        if stem.lower().endswith(".txt"):
            return stem
        return f"{stem or 'decrypted_output'}.txt"
    return f"{filename}_decrypted.txt"


def _mask_key(key_str: str) -> str:
    if not key_str:
        return ""
    if len(key_str) <= 10:
        return "••••••••"
    return f"{key_str[:4]}{'•' * 36}{key_str[-4:]}"


def create_app(test_config: dict[str, object] | None = None) -> Flask:
    """Application factory for SecureVault."""
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)

    Config.STORAGE_DIR = Path(app.config["STORAGE_DIR"]).resolve()
    Config.UPLOADS_DIR = Config.STORAGE_DIR / "uploads"
    Config.ENCRYPTED_DIR = Config.STORAGE_DIR / "encrypted"
    Config.DECRYPTED_DIR = Config.STORAGE_DIR / "decrypted"
    Config.SAMPLES_DIR = Config.STORAGE_DIR / "samples"
    Config.DATABASE_PATH = Path(app.config.get("DATABASE_PATH", Config.STORAGE_DIR / "securevault.db"))
    Config.LOGS_DIR = Path(app.config["LOGS_DIR"]).resolve()
    Config.LOG_FILE = Config.LOGS_DIR / "securevault.log"

    Config.ensure_directories()
    _seed_sample_files(Config.SAMPLES_DIR)

    logger = configure_logging(Config.LOG_FILE)
    file_handler = FileHandler(
        Config.STORAGE_DIR, max_upload_bytes=int(app.config["MAX_CONTENT_LENGTH"])
    )
    history = HistoryManager(Config.DATABASE_PATH)

    def get_csrf_token() -> str:
        token = session.get("_csrf_token")
        if not token:
            token = secrets.token_urlsafe(32)
            session["_csrf_token"] = token
        return token

    @app.context_processor
    def inject_globals() -> dict[str, object]:
        active_key = session.get("active_fernet_key", "")
        return {
            "csrf_token": get_csrf_token(),
            "has_session_key": bool(active_key),
            "masked_session_key": _mask_key(active_key),
            "active_endpoint": request.endpoint or "",
        }

    @app.template_filter("format_bytes")
    def format_bytes_filter(value: int | None) -> str:
        if value is None:
            return "—"
        if value < 1024:
            return f"{value} B"
        kb = value / 1024
        if kb < 1024:
            return f"{kb:.1f} KB"
        return f"{kb / 1024:.2f} MB"

    @app.template_filter("format_dt")
    def format_dt_filter(iso_value: str) -> str:
        try:
            dt = datetime.fromisoformat(iso_value)
            return dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        except Exception:
            return iso_value

    @app.before_request
    def enforce_csrf() -> None:
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            expected = session.get("_csrf_token", "")
            provided = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token", "")
            if not expected or not provided or not hmac.compare_digest(expected, provided):
                logger.warning("Blocked request with missing or invalid CSRF token on %s.", request.path)
                abort(403, description="Invalid or expired security token. Please refresh and try again.")

    @app.after_request
    def apply_security_headers(response: Response) -> Response:
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        return response

    @app.get("/")
    def dashboard() -> str:
        stats = history.get_dashboard_stats()
        recent_activity = history.get_operation_history(limit=6)
        return render_template(
            "dashboard.html",
            page_title="Dashboard",
            stats=stats,
            recent_activity=recent_activity,
        )

    @app.route("/encrypt", methods=["GET", "POST"])
    def encrypt_route() -> str | Response:
        sample_files = file_handler.list_directory_files(Config.SAMPLES_DIR)
        result_data: dict[str, object] | None = None

        if request.method == "POST":
            uploaded = request.files.get("file")
            sample_choice = request.form.get("sample_file", "").strip()
            key_source = request.form.get("key_source", "session")
            custom_key = request.form.get("custom_key", "")
            raw_key = session.get("active_fernet_key", "") if key_source == "session" else custom_key

            temp_upload_path: Path | None = None
            filename = "unknown"
            input_size = 0

            try:
                if sample_choice:
                    safe_sample = file_handler.validate_file(
                        sample_choice,
                        (Config.SAMPLES_DIR / Path(sample_choice).name).stat().st_size
                        if (Config.SAMPLES_DIR / Path(sample_choice).name).exists()
                        else 0,
                        Config.ALLOWED_ENCRYPT_EXTENSIONS,
                    )
                    source_path = file_handler.resolve_confined_path(Config.SAMPLES_DIR, safe_sample)
                    filename = safe_sample
                    input_size = source_path.stat().st_size
                else:
                    if not uploaded or not uploaded.filename:
                        raise FileValidationError(
                            "No file selected. Please choose or drop a .txt file to encrypt."
                        )
                    raw_bytes = uploaded.read()
                    input_size = len(raw_bytes)
                    safe_name = file_handler.validate_file(
                        uploaded.filename, input_size, Config.ALLOWED_ENCRYPT_EXTENSIONS
                    )
                    filename = safe_name
                    temp_upload_path, _ = file_handler.resolve_unique_output_path(
                        Config.UPLOADS_DIR, safe_name
                    )
                    file_handler.write_binary_file(temp_upload_path, raw_bytes)
                    source_path = temp_upload_path

                output_path, renamed = file_handler.resolve_unique_output_path(
                    Config.ENCRYPTED_DIR, f"{filename}.enc"
                )
                manager = EncryptionManager(raw_key)
                meta = manager.encrypt_file(source_path, output_path)

                msg = (
                    f"Encrypted successfully (saved as {output_path.name} to avoid overwriting existing file)."
                    if renamed
                    else "Encrypted successfully using Fernet (AES-128-CBC + HMAC-SHA256)."
                )
                history.save_operation(
                    filename=filename,
                    operation="encrypt",
                    status="success",
                    output_filename=output_path.name,
                    input_size_bytes=int(meta["input_size_bytes"]),
                    output_size_bytes=int(meta["output_size_bytes"]),
                    message=msg,
                )
                result_data = {
                    "input_filename": filename,
                    "output_filename": output_path.name,
                    "output_location": f"storage/encrypted/{output_path.name}",
                    "input_size_bytes": meta["input_size_bytes"],
                    "output_size_bytes": meta["output_size_bytes"],
                    "renamed": renamed,
                    "message": msg,
                }
                flash(f"Encrypted '{filename}' -> '{output_path.name}'.", "success")

            except (
                FileValidationError,
                KeyManagementError,
                EncryptionError,
                FileNotFoundError,
            ) as exc:
                history.save_operation(
                    filename=filename,
                    operation="encrypt",
                    status="failed",
                    output_filename=None,
                    input_size_bytes=input_size,
                    message=str(exc),
                )
                logger.warning("Encryption failed for '%s': %s", filename, str(exc))
                flash(str(exc), "error")
            except PermissionError:
                msg = "Permission denied while accessing private storage."
                history.save_operation(
                    filename=filename,
                    operation="encrypt",
                    status="failed",
                    output_filename=None,
                    input_size_bytes=input_size,
                    message=msg,
                )
                flash(msg, "error")
            except Exception:
                msg = "An unexpected error occurred during encryption."
                logger.exception("Unexpected encryption error for '%s'.", filename)
                history.save_operation(
                    filename=filename,
                    operation="encrypt",
                    status="failed",
                    output_filename=None,
                    input_size_bytes=input_size,
                    message=msg,
                )
                flash(msg, "error")
            finally:
                if temp_upload_path and temp_upload_path.exists():
                    try:
                        temp_upload_path.unlink()
                    except OSError:
                        pass

        return render_template(
            "encrypt.html",
            page_title="Encrypt File",
            sample_files=sample_files,
            result=result_data,
        )

    @app.route("/decrypt", methods=["GET", "POST"])
    def decrypt_route() -> str | Response:
        encrypted_files = file_handler.list_directory_files(Config.ENCRYPTED_DIR)
        preselected = request.args.get("file", "").strip()
        result_data: dict[str, object] | None = None

        if request.method == "POST":
            uploaded = request.files.get("file")
            vault_choice = request.form.get("vault_file", "").strip()
            key_source = request.form.get("key_source", "session")
            custom_key = request.form.get("custom_key", "")
            raw_key = session.get("active_fernet_key", "") if key_source == "session" else custom_key

            temp_upload_path: Path | None = None
            filename = "unknown"
            input_size = 0

            try:
                if vault_choice:
                    safe_vault_name = file_handler.validate_file(
                        vault_choice,
                        (Config.ENCRYPTED_DIR / Path(vault_choice).name).stat().st_size
                        if (Config.ENCRYPTED_DIR / Path(vault_choice).name).exists()
                        else 0,
                        Config.ALLOWED_DECRYPT_EXTENSIONS,
                    )
                    source_path = file_handler.resolve_confined_path(
                        Config.ENCRYPTED_DIR, safe_vault_name
                    )
                    filename = safe_vault_name
                    input_size = source_path.stat().st_size
                else:
                    if not uploaded or not uploaded.filename:
                        raise FileValidationError(
                            "No encrypted file selected. Please choose or drop a .enc file."
                        )
                    raw_bytes = uploaded.read()
                    input_size = len(raw_bytes)
                    safe_name = file_handler.validate_file(
                        uploaded.filename, input_size, Config.ALLOWED_DECRYPT_EXTENSIONS
                    )
                    filename = safe_name
                    temp_upload_path, _ = file_handler.resolve_unique_output_path(
                        Config.UPLOADS_DIR, safe_name
                    )
                    file_handler.write_binary_file(temp_upload_path, raw_bytes)
                    source_path = temp_upload_path

                desired_name = _strip_enc_extension(filename)
                output_path, renamed = file_handler.resolve_unique_output_path(
                    Config.DECRYPTED_DIR, desired_name
                )
                manager = DecryptionManager(raw_key)
                meta = manager.decrypt_file(source_path, output_path)
                preview_bytes = meta["plaintext_bytes"]
                preview_text = (
                    preview_bytes.decode("utf-8", errors="replace")[:6000]
                    if isinstance(preview_bytes, bytes)
                    else ""
                )

                msg = (
                    f"Decrypted successfully (saved as {output_path.name} to preserve existing file)."
                    if renamed
                    else "Decrypted and HMAC-verified successfully."
                )
                history.save_operation(
                    filename=filename,
                    operation="decrypt",
                    status="success",
                    output_filename=output_path.name,
                    input_size_bytes=int(meta["input_size_bytes"]),
                    output_size_bytes=int(meta["output_size_bytes"]),
                    message=msg,
                )
                result_data = {
                    "input_filename": filename,
                    "output_filename": output_path.name,
                    "output_location": f"storage/decrypted/{output_path.name}",
                    "input_size_bytes": meta["input_size_bytes"],
                    "output_size_bytes": meta["output_size_bytes"],
                    "renamed": renamed,
                    "message": msg,
                    "preview_text": preview_text,
                }
                flash(f"Decrypted '{filename}' -> '{output_path.name}'.", "success")

            except (
                FileValidationError,
                KeyManagementError,
                DecryptionError,
                FileNotFoundError,
            ) as exc:
                history.save_operation(
                    filename=filename,
                    operation="decrypt",
                    status="failed",
                    output_filename=None,
                    input_size_bytes=input_size,
                    message=str(exc),
                )
                logger.warning("Decryption failed for '%s': %s", filename, str(exc))
                flash(str(exc), "error")
            except PermissionError:
                msg = "Permission denied while accessing private storage."
                history.save_operation(
                    filename=filename,
                    operation="decrypt",
                    status="failed",
                    output_filename=None,
                    input_size_bytes=input_size,
                    message=msg,
                )
                flash(msg, "error")
            except Exception:
                msg = "An unexpected error occurred during decryption."
                logger.exception("Unexpected decryption error for '%s'.", filename)
                history.save_operation(
                    filename=filename,
                    operation="decrypt",
                    status="failed",
                    output_filename=None,
                    input_size_bytes=input_size,
                    message=msg,
                )
                flash(msg, "error")
            finally:
                if temp_upload_path and temp_upload_path.exists():
                    try:
                        temp_upload_path.unlink()
                    except OSError:
                        pass

        return render_template(
            "decrypt.html",
            page_title="Decrypt File",
            encrypted_files=encrypted_files,
            preselected=preselected,
            result=result_data,
        )

    @app.get("/keys")
    def keys_route() -> str:
        active_key = session.get("active_fernet_key", "")
        return render_template(
            "keys.html",
            page_title="Key Management",
            active_key=active_key,
        )

    @app.post("/keys/generate")
    def keys_generate() -> Response:
        confirm_overwrite = request.form.get("confirm_overwrite") == "1"
        if session.get("active_fernet_key") and not confirm_overwrite:
            flash(
                "An active key is already loaded in your session. Confirm replacement before generating a new key.",
                "error",
            )
            return redirect(url_for("keys_route"))

        key_bytes = KeyManager.generate_key()
        session["active_fernet_key"] = key_bytes.decode("ascii")
        flash(
            "Generated a new 32-byte Fernet key in session memory. Download a backup .key file right away.",
            "success",
        )
        return redirect(url_for("keys_route"))

    @app.post("/keys/validate")
    def keys_load() -> Response:
        raw_input = request.form.get("key_value", "")
        key_file = request.files.get("key_file")
        if key_file and key_file.filename:
            raw_input = key_file.read().decode("utf-8", errors="ignore")

        try:
            validated = KeyManager.validate_key(raw_input)
            key_str = validated.decode("ascii")
            confirm_overwrite = request.form.get("confirm_overwrite") == "1"
            existing = session.get("active_fernet_key", "")
            if existing and existing != key_str and not confirm_overwrite:
                flash(
                    "An active key already exists in your session. Confirm replacement to load a different key.",
                    "error",
                )
                return redirect(url_for("keys_route"))

            session["active_fernet_key"] = key_str
            flash("Fernet key validated and loaded into session memory.", "success")
        except KeyManagementError as exc:
            flash(str(exc), "error")
        return redirect(url_for("keys_route"))

    @app.post("/keys/download")
    def keys_download() -> Response:
        active_key = session.get("active_fernet_key", "")
        if not active_key:
            flash("No active session key to download. Generate or load a key first.", "error")
            return redirect(url_for("keys_route"))

        stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        filename = f"securevault_{stamp}.key"
        logger.info("User downloaded key backup file '%s' (key value omitted).", filename)
        return Response(
            f"{active_key}\n",
            mimetype="application/octet-stream",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
                "Cache-Control": "no-store",
            },
        )

    @app.post("/keys/clear")
    def keys_clear() -> Response:
        session.pop("active_fernet_key", None)
        flash("Active encryption key cleared from session memory.", "info")
        return redirect(url_for("keys_route"))

    @app.get("/history")
    def history_route() -> str:
        op_filter = request.args.get("operation", "all")
        status_filter = request.args.get("status", "all")
        search_q = request.args.get("q", "").strip()
        records = history.get_operation_history(
            operation=op_filter, status=status_filter, search_query=search_q
        )
        return render_template(
            "history.html",
            page_title="Activity History",
            records=records,
            op_filter=op_filter,
            status_filter=status_filter,
            search_q=search_q,
        )

    @app.get("/guide")
    def guide_route() -> str:
        return render_template("guide.html", page_title="Security Guide")

    @app.get("/download/<category>/<filename>")
    def safe_download(category: str, filename: str) -> Response:
        if category not in {"encrypted", "decrypted"}:
            abort(404)
        target_dir = Config.ENCRYPTED_DIR if category == "encrypted" else Config.DECRYPTED_DIR
        try:
            safe_path = file_handler.resolve_confined_path(target_dir, filename)
        except FileValidationError:
            abort(400)
        if not safe_path.exists() or not safe_path.is_file():
            abort(404)

        response = send_file(safe_path, as_attachment=True, download_name=safe_path.name)
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(403)
    def handle_forbidden(err: Exception) -> tuple[str, int]:
        flash(getattr(err, "description", "Security verification failed."), "error")
        return redirect(request.referrer or url_for("dashboard")), 403

    @app.errorhandler(413)
    def handle_too_large(_err: Exception) -> tuple[str, int]:
        flash(
            f"Uploaded file exceeds the {app.config['MAX_UPLOAD_MB']} MB maximum size limit.",
            "error",
        )
        return redirect(request.referrer or url_for("dashboard")), 413

    @app.errorhandler(404)
    def handle_not_found(_err: Exception) -> tuple[str, int]:
        return render_template("guide.html", page_title="Not Found", not_found=True), 404

    @app.errorhandler(500)
    def handle_server_error(_err: Exception) -> tuple[str, int]:
        logger.exception("Unhandled server exception occurred.")
        flash("An unexpected server error occurred. Please try again.", "error")
        return redirect(url_for("dashboard")), 500

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=Config.DEBUG)
