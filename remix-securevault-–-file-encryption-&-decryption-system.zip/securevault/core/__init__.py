"""Core cryptographic, file handling, key management, and audit history modules."""

from importlib import import_module
from typing import Any

__all__ = [
    "EncryptionManager",
    "EncryptionError",
    "encrypt_file",
    "DecryptionManager",
    "DecryptionError",
    "decrypt_file",
    "KeyManager",
    "KeyManagementError",
    "generate_key",
    "FileHandler",
    "FileValidationError",
    "validate_file",
    "HistoryManager",
    "save_operation",
    "get_operation_history",
]

_EXPORTS = {
    "EncryptionManager": ".encryption",
    "EncryptionError": ".encryption",
    "encrypt_file": ".encryption",
    "DecryptionManager": ".decryption",
    "DecryptionError": ".decryption",
    "decrypt_file": ".decryption",
    "KeyManager": ".key_manager",
    "KeyManagementError": ".key_manager",
    "generate_key": ".key_manager",
    "FileHandler": ".file_handler",
    "FileValidationError": ".file_handler",
    "validate_file": ".file_handler",
    "HistoryManager": ".history",
    "save_operation": ".history",
    "get_operation_history": ".history",
}


def __getattr__(name: str) -> Any:
    if name in _EXPORTS:
        module = import_module(_EXPORTS[name], __name__)
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
