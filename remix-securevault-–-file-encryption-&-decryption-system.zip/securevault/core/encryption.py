"""Fernet symmetric file encryption logic using the cryptography package."""

import logging
from pathlib import Path
from cryptography.fernet import Fernet

from .file_handler import FileHandler
from .key_manager import KeyManager


logger = logging.getLogger("securevault.encryption")


class EncryptionError(Exception):
    """Raised when encryption fails due to invalid inputs, keys, or file I/O errors."""


class EncryptionManager:
    """Encrypts validated binary/plain-text files using Fernet (AES-128-CBC + HMAC-SHA256)."""

    def __init__(self, key: bytes | str) -> None:
        normalized_key = KeyManager.validate_key(key)
        self._fernet = Fernet(normalized_key)

    def encrypt_bytes(self, plaintext: bytes) -> bytes:
        """Encrypt non-empty binary bytes into a Fernet token."""
        if not plaintext:
            raise EncryptionError("Cannot encrypt an empty file (0 bytes).")
        return self._fernet.encrypt(plaintext)

    def encrypt_file(self, input_path: Path, output_path: Path) -> dict[str, object]:
        """Read binary data from input_path, encrypt with Fernet, and write to output_path."""
        handler = FileHandler(input_path.parent)
        raw_bytes = handler.read_binary_file(input_path)
        if not raw_bytes:
            raise EncryptionError(
                f"Cannot encrypt '{input_path.name}': the file is empty (0 bytes)."
            )

        encrypted_bytes = self.encrypt_bytes(raw_bytes)
        written_bytes = handler.write_binary_file(output_path, encrypted_bytes)
        logger.info(
            "Encrypted '%s' (%d bytes) -> '%s' (%d bytes).",
            input_path.name,
            len(raw_bytes),
            output_path.name,
            written_bytes,
        )
        return {
            "input_filename": input_path.name,
            "output_filename": output_path.name,
            "input_size_bytes": len(raw_bytes),
            "output_size_bytes": written_bytes,
        }


def encrypt_file(input_path: Path, output_path: Path, key: bytes | str) -> dict[str, object]:
    """Standalone function encrypting input_path to output_path with a Fernet key."""
    manager = EncryptionManager(key)
    return manager.encrypt_file(input_path, output_path)
