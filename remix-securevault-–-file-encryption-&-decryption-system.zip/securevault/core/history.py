"""SQLite-backed audit history manager using parameterized queries.

Strictly never stores encryption keys, key hashes, passwords, or plaintext file contents.
"""

from datetime import datetime, timezone
import logging
from pathlib import Path
import sqlite3
import uuid


logger = logging.getLogger("securevault.history")


class HistoryManager:
    """Persists and queries encryption/decryption operation records in SQLite."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _initialize_schema(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS operation_history (
                    id TEXT PRIMARY KEY,
                    filename TEXT NOT NULL,
                    operation TEXT NOT NULL CHECK(operation IN ('encrypt', 'decrypt')),
                    timestamp TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN ('success', 'failed')),
                    output_filename TEXT,
                    input_size_bytes INTEGER NOT NULL DEFAULT 0,
                    output_size_bytes INTEGER,
                    message TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_history_timestamp
                ON operation_history (timestamp DESC)
                """
            )
            conn.commit()

    def save_operation(
        self,
        *,
        filename: str,
        operation: str,
        status: str,
        output_filename: str | None = None,
        input_size_bytes: int = 0,
        output_size_bytes: int | None = None,
        message: str = "",
    ) -> str:
        """Record an encryption or decryption attempt without logging secrets."""
        record_id = str(uuid.uuid4())
        timestamp = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO operation_history (
                    id, filename, operation, timestamp, status,
                    output_filename, input_size_bytes, output_size_bytes, message
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record_id,
                    filename,
                    operation,
                    timestamp,
                    status,
                    output_filename,
                    int(input_size_bytes),
                    int(output_size_bytes) if output_size_bytes is not None else None,
                    message,
                ),
            )
            conn.commit()
        return record_id

    def get_operation_history(
        self,
        *,
        operation: str = "all",
        status: str = "all",
        search_query: str = "",
        limit: int = 200,
    ) -> list[dict[str, object]]:
        """Query filtered operation history with parameterized SQL."""
        clauses: list[str] = []
        params: list[object] = []

        if operation in {"encrypt", "decrypt"}:
            clauses.append("operation = ?")
            params.append(operation)

        if status in {"success", "failed"}:
            clauses.append("status = ?")
            params.append(status)

        cleaned_q = search_query.strip()
        if cleaned_q:
            like_pattern = f"%{cleaned_q}%"
            clauses.append(
                "(filename LIKE ? OR COALESCE(output_filename, '') LIKE ? OR message LIKE ?)"
            )
            params.extend([like_pattern, like_pattern, like_pattern])

        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"""
            SELECT id, filename, operation, timestamp, status,
                   output_filename, input_size_bytes, output_size_bytes, message
            FROM operation_history
            {where_sql}
            ORDER BY timestamp DESC
            LIMIT ?
        """
        params.append(int(limit))

        with self._connect() as conn:
            rows = conn.execute(sql, tuple(params)).fetchall()

        return [dict(row) for row in rows]

    def get_dashboard_stats(self) -> dict[str, int]:
        """Compute live dashboard totals directly from SQLite records."""
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT
                    COUNT(*) AS total_processed,
                    COALESCE(SUM(CASE WHEN operation = 'encrypt' AND status = 'success' THEN 1 ELSE 0 END), 0) AS successful_encryptions,
                    COALESCE(SUM(CASE WHEN operation = 'decrypt' AND status = 'success' THEN 1 ELSE 0 END), 0) AS successful_decryptions,
                    COALESCE(SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END), 0) AS failed_operations
                FROM operation_history
                """
            ).fetchone()

        if row is None:
            return {
                "total_processed": 0,
                "successful_encryptions": 0,
                "successful_decryptions": 0,
                "failed_operations": 0,
            }

        return {
            "total_processed": int(row["total_processed"]),
            "successful_encryptions": int(row["successful_encryptions"]),
            "successful_decryptions": int(row["successful_decryptions"]),
            "failed_operations": int(row["failed_operations"]),
        }


def save_operation(
    db_path: Path,
    *,
    filename: str,
    operation: str,
    status: str,
    output_filename: str | None = None,
    input_size_bytes: int = 0,
    output_size_bytes: int | None = None,
    message: str = "",
) -> str:
    """Standalone helper wrapping HistoryManager.save_operation."""
    manager = HistoryManager(db_path)
    return manager.save_operation(
        filename=filename,
        operation=operation,
        status=status,
        output_filename=output_filename,
        input_size_bytes=input_size_bytes,
        output_size_bytes=output_size_bytes,
        message=message,
    )


def get_operation_history(
    db_path: Path,
    *,
    operation: str = "all",
    status: str = "all",
    search_query: str = "",
    limit: int = 200,
) -> list[dict[str, object]]:
    """Standalone helper wrapping HistoryManager.get_operation_history."""
    manager = HistoryManager(db_path)
    return manager.get_operation_history(
        operation=operation,
        status=status,
        search_query=search_query,
        limit=limit,
    )
