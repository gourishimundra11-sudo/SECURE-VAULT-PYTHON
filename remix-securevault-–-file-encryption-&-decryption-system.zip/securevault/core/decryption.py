"""Fernet symmetric file decryption logic with InvalidToken and corruption handling."""

import logging
from pathlib import Path
from cryptography.fernet import Fernet, InvalidToken

from .file_handler import FileHandler
from .key_manager import KeyManager


logger = logging.getLogger("securevault.decryption")


class DecryptionError(Exception):
    """Raised when decryption fails due to an incorrect key or corrupted ciphertext."""


class DecryptionManager:
    """Verifies HMAC-SHA256 and decrypts Fernet-encrypted .enc files."""

    def __init__(self, key: bytes | str) -> None:
        normalized_key = KeyManager.validate_key(key)
        self._fernet = Fernet(normalized_key)

    def decrypt_bytes(self, token: bytes) -> bytes:
        """Verify token integrity and decrypt ciphertext bytes."""
        cleaned = token.strip()
        if not cleaned:
            raise DecryptionError("The selected encrypted file is empty (0 bytes).")
        try:
            return self._fernet.decrypt(cleaned)
        except InvalidToken as exc:
            logger.warning("Decryption rejected: InvalidToken (wrong key or corrupted file).")
            raise DecryptionError(
                "Decryption failed: the encryption key is incorrect, or the encrypted file has been corrupted or modified."
            ) from exc

    def decrypt_file(self, input_path: Path, output_path: Path) -> dict[str, object]:
        """Read encrypted .enc bytes, decrypt with Fernet, and write original content."""
        handler = FileHandler(input_path.parent)
        token_bytes = handler.read_binary_file(input_path)
        if not token_bytes.strip():
            raise DecryptionError(
                f"Cannot decrypt '{input_path.name}': the encrypted file is empty."
            )

        plaintext_bytes = self.decrypt_bytes(token_bytes)
        written_bytes = handler.write_binary_file(output_path, plaintext_bytes)
        logger.info(
            "Decrypted '%s' (%d bytes) -> '%s' (%d bytes).",
            input_path.name,
            len(token_bytes),
            output_path.name,
            written_bytes,
        )
        return {
            "input_filename": input_path.name,
            "output_filename": output_path.name,
            "input_size_bytes": len(token_bytes),
            "output_size_bytes": written_bytes,
            "plaintext_bytes": plaintext_bytes,
        }


def decrypt_file(input_path: Path, output_path: Path, key: bytes | str) -> dict[str, object]:
    """Standalone function decrypting input_path to output_path with a Fernet key."""
    manager = DecryptionManager(key)
    return manager.decrypt_file(input_path, output_path)
