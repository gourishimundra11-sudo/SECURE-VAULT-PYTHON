"""Fernet symmetric key generation, validation, and non-logging key management."""

import logging
from pathlib import Path
from cryptography.fernet import Fernet


logger = logging.getLogger("securevault.key_manager")


class KeyManagementError(ValueError):
    """Raised when a Fernet key is missing, malformed, or cannot be validated."""


class KeyManager:
    """Manages cryptographic Fernet keys in memory without logging secrets."""

    @staticmethod
    def generate_key() -> bytes:
        """Generate a fresh 32-byte URL-safe Base64 Fernet symmetric key."""
        key = Fernet.generate_key()
        logger.info("Generated new 256-bit Fernet symmetric key (value omitted).")
        return key

    @staticmethod
    def validate_key(raw_key: str | bytes) -> bytes:
        """Validate a user-supplied Fernet key and return normalized ASCII key bytes."""
        if isinstance(raw_key, bytes):
            candidate = raw_key.strip()
        elif isinstance(raw_key, str):
            candidate = raw_key.strip().encode("utf-8")
        else:
            raise KeyManagementError("No encryption key provided.")

        if not candidate:
            raise KeyManagementError(
                "Missing encryption key. Generate a new key or provide an existing Fernet key."
            )

        try:
            Fernet(candidate)
        except Exception as exc:
            logger.warning("Fernet key validation failed due to invalid key format.")
            raise KeyManagementError(
                "Invalid Fernet key format. Expected a 44-character URL-safe Base64 key."
            ) from exc

        return candidate

    @staticmethod
    def save_key_file(target_path: Path, key_bytes: bytes) -> None:
        """Write a .key file safely without silently overwriting an existing key file."""
        if target_path.exists():
            raise KeyManagementError(
                f"Refusing to overwrite existing key file '{target_path.name}'."
            )
        target_path.write_bytes(key_bytes + b"\n")
        logger.info("Exported key file '%s' (key value omitted).", target_path.name)


def generate_key() -> bytes:
    """Standalone function generating a cryptographically secure Fernet key."""
    return KeyManager.generate_key()
