"""Secure file I/O, filename sanitization, path confinement, and duplicate-safe naming."""

from datetime import datetime, timezone
import logging
import os
from pathlib import Path
import re


logger = logging.getLogger("securevault.file_handler")


class FileValidationError(ValueError):
    """Raised when an uploaded filename, path, format, or size violates security rules."""


class FileHandler:
    """Manages confined vault file operations using Python pathlib."""

    SAFE_CHARS = re.compile(r"[^A-Za-z0-9._-]")

    def __init__(self, base_dir: Path, max_upload_bytes: int = 5 * 1024 * 1024) -> None:
        self.base_dir = base_dir.resolve()
        self.max_upload_bytes = max_upload_bytes

    def sanitize_filename(self, filename: str) -> str:
        """Strip unsafe characters and reject path traversal attempts."""
        if not filename or not isinstance(filename, str):
            raise FileValidationError("No file selected. Please choose a valid file.")

        trimmed = filename.strip()
        if (
            not trimmed
            or "\x00" in trimmed
            or ".." in trimmed
            or "/" in trimmed
            or "\\" in trimmed
        ):
            raise FileValidationError(
                "Invalid file path: directory traversal and path separators are not permitted."
            )

        cleaned = self.SAFE_CHARS.sub("_", Path(trimmed).name)
        if not cleaned or cleaned in {".", ".."} or cleaned.startswith("."):
            raise FileValidationError(
                "Invalid filename: please provide a standard filename without leading dots."
            )
        return cleaned

    def validate_file(
        self,
        filename: str,
        size_bytes: int,
        allowed_extensions: set[str],
    ) -> str:
        """Validate filename safety, allowed extension, non-empty size, and max upload cap."""
        safe_name = self.sanitize_filename(filename)
        suffix = Path(safe_name).suffix.lower()
        if suffix not in allowed_extensions:
            expected = ", ".join(sorted(allowed_extensions))
            raise FileValidationError(
                f"Unsupported file format '{suffix or 'unknown'}' for '{safe_name}'. Expected: {expected}."
            )

        if size_bytes <= 0:
            raise FileValidationError(
                f"The selected file '{safe_name}' is empty (0 bytes) and cannot be processed."
            )

        if size_bytes > self.max_upload_bytes:
            max_mb = self.max_upload_bytes / (1024 * 1024)
            raise FileValidationError(
                f"File '{safe_name}' exceeds the maximum upload size limit of {max_mb:.1f} MB."
            )

        return safe_name

    def resolve_confined_path(self, target_dir: Path, filename: str) -> Path:
        """Resolve a sanitized filename and assert strict directory confinement."""
        safe_name = self.sanitize_filename(filename)
        resolved_dir = target_dir.resolve()
        candidate = (resolved_dir / safe_name).resolve()
        if candidate.parent != resolved_dir:
            raise FileValidationError(
                "Invalid file path: resolved target escapes the allowed vault directory."
            )
        return candidate

    def resolve_unique_output_path(
        self, target_dir: Path, desired_filename: str
    ) -> tuple[Path, bool]:
        """Return a collision-safe output path so existing files are never overwritten."""
        candidate = self.resolve_confined_path(target_dir, desired_filename)
        if not candidate.exists():
            return candidate, False

        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        stem = candidate.stem or "output"
        suffix = candidate.suffix
        counter = 0

        while True:
            tag = f"_{stamp}" if counter == 0 else f"_{stamp}_{counter}"
            next_candidate = self.resolve_confined_path(
                target_dir, f"{stem}{tag}{suffix}"
            )
            if not next_candidate.exists():
                return next_candidate, True
            counter += 1

    def read_binary_file(self, file_path: Path) -> bytes:
        """Read binary file contents with explicit missing-file and permission handling."""
        if not file_path.exists() or not file_path.is_file():
            raise FileNotFoundError(f"File '{file_path.name}' could not be found.")
        try:
            return file_path.read_bytes()
        except PermissionError:
            logger.error("Permission denied while reading %s", file_path.name)
            raise

    def write_binary_file(self, file_path: Path, data: bytes) -> int:
        """Write binary bytes privately (0o600) without silently overwriting existing files."""
        file_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            file_path.write_bytes(data)
            try:
                os.chmod(file_path, 0o600)
            except OSError:
                pass
            return len(data)
        except PermissionError:
            logger.error("Permission denied while writing %s", file_path.name)
            raise

    def list_directory_files(self, target_dir: Path) -> list[dict[str, object]]:
        """List non-hidden files inside a confined vault directory."""
        if not target_dir.exists():
            return []
        items: list[dict[str, object]] = []
        for entry in target_dir.iterdir():
            if not entry.is_file() or entry.name.startswith("."):
                continue
            stat = entry.stat()
            items.append(
                {
                    "filename": entry.name,
                    "size_bytes": stat.st_size,
                    "updated_at": datetime.fromtimestamp(
                        stat.st_mtime, tz=timezone.utc
                    ).isoformat(),
                }
            )
        return sorted(items, key=lambda item: str(item["updated_at"]), reverse=True)


def validate_file(
    filename: str,
    size_bytes: int,
    allowed_extensions: set[str],
    max_upload_bytes: int = 5 * 1024 * 1024,
) -> str:
    """Standalone helper wrapping FileHandler.validate_file."""
    handler = FileHandler(Path.cwd(), max_upload_bytes=max_upload_bytes)
    return handler.validate_file(filename, size_bytes, allowed_extensions)
