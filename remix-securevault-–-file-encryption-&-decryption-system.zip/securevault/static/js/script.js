document.addEventListener("DOMContentLoaded", () => {
  // Mobile sidebar drawer
  const sidebar = document.getElementById("sv-sidebar");
  const backdrop = document.getElementById("sv-backdrop");
  const openMenuBtn = document.getElementById("sv-open-menu");
  const closeMenuBtn = document.getElementById("sv-close-menu");

  const setMenuOpen = (open) => {
    if (!sidebar || !backdrop) return;
    sidebar.classList.toggle("is-open", open);
    backdrop.classList.toggle("is-open", open);
  };

  if (openMenuBtn) openMenuBtn.addEventListener("click", () => setMenuOpen(true));
  if (closeMenuBtn) closeMenuBtn.addEventListener("click", () => setMenuOpen(false));
  if (backdrop) backdrop.addEventListener("click", () => setMenuOpen(false));

  // Flash alert dismissal
  document.querySelectorAll("[data-dismiss-alert]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const alertEl = btn.closest("[data-alert]");
      if (alertEl) alertEl.remove();
    });
  });

  // Drag-and-drop file upload + metadata display
  document.querySelectorAll("[data-dropzone]").forEach((zone) => {
    const input = zone.querySelector('input[type="file"]');
    const metaBox = document.getElementById(zone.dataset.metaTarget || "");
    const nameEl = metaBox ? metaBox.querySelector("[data-file-name]") : null;
    const sizeEl = metaBox ? metaBox.querySelector("[data-file-size]") : null;
    const typeEl = metaBox ? metaBox.querySelector("[data-file-type]") : null;
    const statusEl = metaBox ? metaBox.querySelector("[data-file-status]") : null;
    const expectedExt = (zone.dataset.expectedExt || "").toLowerCase();

    const formatBytes = (bytes) => {
      if (bytes < 1024) return `${bytes} B`;
      const kb = bytes / 1024;
      if (kb < 1024) return `${kb.toFixed(1)} KB`;
      return `${(kb / 1024).toFixed(2)} MB`;
    };

    const renderFileMeta = (file) => {
      if (!file || !metaBox) return;
      metaBox.hidden = false;
      if (nameEl) nameEl.textContent = file.name;
      if (sizeEl) sizeEl.textContent = formatBytes(file.size);
      if (typeEl) typeEl.textContent = file.type || expectedExt || "binary";
      if (statusEl) {
        const validExt = !expectedExt || file.name.toLowerCase().endsWith(expectedExt);
        if (file.size === 0) {
          statusEl.textContent = "Empty file (0 bytes) — rejected on submit";
          statusEl.className = "sv-status-failed";
        } else if (!validExt) {
          statusEl.textContent = `Unsupported format (expected ${expectedExt})`;
          statusEl.className = "sv-status-failed";
        } else {
          statusEl.textContent = `Validated ${expectedExt} file ready`;
          statusEl.className = "sv-status-success";
        }
      }
    };

    if (input) {
      input.addEventListener("change", () => {
        if (input.files && input.files[0]) {
          renderFileMeta(input.files[0]);
        }
      });
    }

    zone.addEventListener("dragover", (event) => {
      event.preventDefault();
      zone.classList.add("is-dragover");
    });

    zone.addEventListener("dragleave", () => {
      zone.classList.remove("is-dragover");
    });

    zone.addEventListener("drop", (event) => {
      event.preventDefault();
      zone.classList.remove("is-dragover");
      const files = event.dataTransfer ? event.dataTransfer.files : null;
      if (files && files.length > 0 && input) {
        input.files = files;
        renderFileMeta(files[0]);
      }
    });
  });

  // Toggle visibility of secret key inputs or session key previews
  document.querySelectorAll("[data-toggle-visibility]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = document.getElementById(btn.dataset.toggleVisibility || "");
      if (!target) return;
      if (target.tagName === "INPUT") {
        const isPwd = target.getAttribute("type") === "password";
        target.setAttribute("type", isPwd ? "text" : "password");
        btn.textContent = isPwd ? "Hide" : "Reveal";
      } else {
        const masked = target.dataset.masked || "";
        const plain = target.dataset.plain || "";
        const isRevealed = target.dataset.revealed === "1";
        target.textContent = isRevealed ? masked : plain;
        target.dataset.revealed = isRevealed ? "0" : "1";
        btn.textContent = isRevealed ? "Reveal" : "Hide";
      }
    });
  });

  // Copy key to clipboard
  document.querySelectorAll("[data-copy-target]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const target = document.getElementById(btn.dataset.copyTarget || "");
      if (!target) return;
      const value = target.dataset.plain || target.textContent || "";
      try {
        await navigator.clipboard.writeText(value.trim());
        const prev = btn.textContent;
        btn.textContent = "Copied";
        setTimeout(() => {
          btn.textContent = prev;
        }, 1800);
      } catch {
        btn.textContent = "Copy blocked";
      }
    });
  });

  // Load .key file directly into a text/password input
  document.querySelectorAll("[data-key-file-input]").forEach((fileInput) => {
    fileInput.addEventListener("change", async () => {
      const target = document.getElementById(fileInput.dataset.keyFileInput || "");
      const file = fileInput.files && fileInput.files[0];
      if (!file || !target) return;
      const text = (await file.text()).trim();
      target.value = text;
    });
  });

  // Submit processing indicator
  document.querySelectorAll("form[data-processing-label]").forEach((form) => {
    form.addEventListener("submit", () => {
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.textContent = form.dataset.processingLabel || "Processing...";
        submitBtn.disabled = true;
      }
    });
  });
});
