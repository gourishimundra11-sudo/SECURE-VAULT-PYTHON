"""Unit and integration test suite for SecureVault."""

from io import BytesIO
from pathlib import Path
import re
import sqlite3
import tempfile
import unittest

from core.file_handler import FileHandler, FileValidationError, validate_file
from core.history import HistoryManager, get_operation_history, save_operation

try:
    from cryptography.fernet import Fernet  # noqa: F401
    import flask  # noqa: F401

    HAS_CRYPTO_AND_FLASK = True
except ImportError:
    HAS_CRYPTO_AND_FLASK = False


class TestFileHandlerAndHistory(unittest.TestCase):
    """Tests pure-Python file safety, collision naming, and SQLite audit history."""

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.handler = FileHandler(self.root, max_upload_bytes=1024 * 1024)
        self.db_path = self.root / "history.db"
        self.history = HistoryManager(self.db_path)

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_rejects_path_traversal_and_separators(self) -> None:
        for bad_name in ("../secret.txt", "sub/file.txt", "a\\b.txt", ".hidden.txt", ""):
            with self.assertRaises(FileValidationError):
                self.handler.sanitize_filename(bad_name)

    def test_validates_extension_and_non_empty_size(self) -> None:
        safe = validate_file("report.txt", 120, {".txt"})
        self.assertEqual(safe, "report.txt")

        with self.assertRaises(FileValidationError):
            validate_file("malware.exe", 120, {".txt"})

        with self.assertRaises(FileValidationError):
            validate_file("empty.txt", 0, {".txt"})

    def test_missing_file_raises_file_not_found(self) -> None:
        missing = self.root / "does_not_exist.txt"
        with self.assertRaises(FileNotFoundError):
            self.handler.read_binary_file(missing)

    def test_duplicate_output_filename_is_never_overwritten(self) -> None:
        out_dir = self.root / "encrypted"
        out_dir.mkdir()
        first, renamed_first = self.handler.resolve_unique_output_path(out_dir, "notes.txt.enc")
        self.assertFalse(renamed_first)
        self.handler.write_binary_file(first, b"cipher-v1")

        second, renamed_second = self.handler.resolve_unique_output_path(out_dir, "notes.txt.enc")
        self.assertTrue(renamed_second)
        self.assertNotEqual(first.name, second.name)
        self.assertEqual(first.read_bytes(), b"cipher-v1")

    def test_sqlite_history_records_and_filters_without_secrets(self) -> None:
        save_operation(
            self.db_path,
            filename="alpha.txt",
            operation="encrypt",
            status="success",
            output_filename="alpha.txt.enc",
            input_size_bytes=50,
            output_size_bytes=140,
            message="Encrypted successfully.",
        )
        save_operation(
            self.db_path,
            filename="beta.enc",
            operation="decrypt",
            status="failed",
            output_filename=None,
            input_size_bytes=140,
            message="Incorrect key.",
        )

        stats = self.history.get_dashboard_stats()
        self.assertEqual(stats["total_processed"], 2)
        self.assertEqual(stats["successful_encryptions"], 1)
        self.assertEqual(stats["failed_operations"], 1)

        enc_only = get_operation_history(self.db_path, operation="encrypt")
        self.assertEqual(len(enc_only), 1)
        self.assertEqual(enc_only[0]["filename"], "alpha.txt")

        with sqlite3.connect(self.db_path) as conn:
            cols = [row[1] for row in conn.execute("PRAGMA table_info(operation_history)")]
        self.assertNotIn("key", cols)
        self.assertNotIn("secret", cols)


@unittest.skipUnless(
    HAS_CRYPTO_AND_FLASK,
    "Requires Flask and cryptography installed via pip install -r requirements.txt",
)
class TestEncryptionAndFlaskApp(unittest.TestCase):
    """End-to-end cryptographic and Flask route tests."""

    def setUp(self) -> None:
        from app import create_app

        self._tmp = tempfile.TemporaryDirectory()
        root = Path(self._tmp.name)
        self.app = create_app(
            {
                "TESTING": True,
                "STORAGE_DIR": root / "storage",
                "DATABASE_PATH": root / "storage" / "test.db",
                "LOGS_DIR": root / "logs",
            }
        )
        self.client = self.app.test_client()

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def _get_csrf(self, html: str) -> str:
        match = re.search(r'name="csrf_token"\s+value="([^"]+)"', html)
        self.assertIsNotNone(match)
        return match.group(1)  # type: ignore[union-attr]

    def test_encryption_decryption_round_trip_and_invalid_key(self) -> None:
        from core.decryption import DecryptionError, decrypt_file
        from core.encryption import encrypt_file
        from core.key_manager import generate_key

        key = generate_key()
        wrong_key = generate_key()
        root = Path(self._tmp.name)
        src = root / "sample.txt"
        enc = root / "sample.txt.enc"
        dec = root / "sample_out.txt"
        src.write_bytes(b"Confidential academic test payload 2026")

        encrypt_file(src, enc, key)
        self.assertTrue(enc.exists())
        self.assertNotEqual(enc.read_bytes(), src.read_bytes())

        with self.assertRaises(DecryptionError):
            decrypt_file(enc, dec, wrong_key)

        decrypt_file(enc, dec, key)
        self.assertEqual(dec.read_bytes(), src.read_bytes())

    def test_flask_routes_csrf_and_end_to_end_workflow(self) -> None:
        # Verify all pages render cleanly
        for path in ("/", "/encrypt", "/decrypt", "/keys", "/history", "/guide"):
            res = self.client.get(path)
            self.assertEqual(res.status_code, 200)

        # Verify CSRF rejects missing token
        bad_post = self.client.post("/keys/generate", data={})
        self.assertEqual(bad_post.status_code, 403)

        # Generate key with CSRF
        keys_page = self.client.get("/keys").get_data(as_text=True)
        csrf = self._get_csrf(keys_page)
        gen_res = self.client.post(
            "/keys/generate", data={"csrf_token": csrf}, follow_redirects=True
        )
        self.assertEqual(gen_res.status_code, 200)

        # Encrypt uploaded .txt file
        enc_res = self.client.post(
            "/encrypt",
            data={
                "csrf_token": csrf,
                "key_source": "session",
                "file": (BytesIO(b"Top secret syllabus notes"), "notes.txt"),
            },
            content_type="multipart/form-data",
        )
        self.assertEqual(enc_res.status_code, 200)
        enc_html = enc_res.get_data(as_text=True)
        self.assertIn("notes.txt.enc", enc_html)

        # Decrypt from vault
        dec_res = self.client.post(
            "/decrypt",
            data={
                "csrf_token": csrf,
                "key_source": "session",
                "vault_file": "notes.txt.enc",
            },
        )
        self.assertEqual(dec_res.status_code, 200)
        self.assertIn("Top secret syllabus notes", dec_res.get_data(as_text=True))

        # Reject unsupported extension
        bad_ext = self.client.post(
            "/encrypt",
            data={
                "csrf_token": csrf,
                "key_source": "session",
                "file": (BytesIO(b"binary"), "script.py"),
            },
            content_type="multipart/form-data",
        )
        self.assertIn("Unsupported file format", bad_ext.get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
