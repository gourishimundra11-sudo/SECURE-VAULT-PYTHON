import crypto from 'node:crypto';

export type FernetErrorCode =
  | 'INVALID_KEY'
  | 'EMPTY_INPUT'
  | 'CORRUPTED_TOKEN'
  | 'WRONG_KEY';

export class FernetError extends Error {
  public readonly code: FernetErrorCode;

  constructor(code: FernetErrorCode, message: string) {
    super(message);
    this.name = 'FernetError';
    this.code = code;
  }
}

function toBase64UrlPadded(buffer: Buffer): string {
  const b64 = buffer
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
  return b64;
}

function fromBase64UrlStrict(input: string, errorCode: FernetErrorCode, label: string): Buffer {
  const trimmed = input.trim();
  if (!trimmed) {
    throw new FernetError(errorCode, `${label} cannot be empty.`);
  }
  if (!/^[A-Za-z0-9_-]+={0,2}$/.test(trimmed)) {
    throw new FernetError(
      errorCode,
      `${label} contains invalid characters. Expected URL-safe Base64 format.`
    );
  }
  const normalized = trimmed.replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=');
  return Buffer.from(padded, 'base64');
}

export class FernetCipher {
  private static readonly VERSION = 0x80;
  private static readonly MIN_TOKEN_BYTES = 1 + 8 + 16 + 16 + 32; // 73 bytes

  /**
   * Generates a cryptographically secure 32-byte Fernet key encoded in URL-safe Base64.
   */
  public static generateKey(): string {
    const rawKey = crypto.randomBytes(32);
    return toBase64UrlPadded(rawKey);
  }

  /**
   * Validates a URL-safe Base64 Fernet key and splits it into 16-byte signing and encryption keys.
   */
  public static parseKey(rawKey: string): { signingKey: Buffer; encryptionKey: Buffer } {
    if (typeof rawKey !== 'string' || !rawKey.trim()) {
      throw new FernetError(
        'INVALID_KEY',
        'No encryption key provided. Please generate or load a valid Fernet key.'
      );
    }

    const decoded = fromBase64UrlStrict(rawKey, 'INVALID_KEY', 'Encryption key');
    if (decoded.length !== 32) {
      throw new FernetError(
        'INVALID_KEY',
        `Invalid Fernet key length (${decoded.length} bytes). A valid Fernet key must decode to exactly 32 bytes (44 URL-safe Base64 characters).`
      );
    }

    return {
      signingKey: decoded.subarray(0, 16),
      encryptionKey: decoded.subarray(16, 32),
    };
  }

  /**
   * Encrypts plaintext bytes using the standard Fernet specification (AES-128-CBC + PKCS7 + HMAC-SHA256).
   */
  public static encrypt(plaintext: Buffer, rawKey: string): Buffer {
    if (!plaintext || plaintext.length === 0) {
      throw new FernetError('EMPTY_INPUT', 'Cannot encrypt an empty file. Please select a file containing text.');
    }

    const { signingKey, encryptionKey } = FernetCipher.parseKey(rawKey);

    const version = Buffer.from([FernetCipher.VERSION]);
    const timestamp = Buffer.alloc(8);
    const epochSeconds = BigInt(Math.floor(Date.now() / 1000));
    timestamp.writeBigUInt64BE(epochSeconds, 0);

    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-128-cbc', encryptionKey, iv);
    const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);

    const basicParts = Buffer.concat([version, timestamp, iv, ciphertext]);
    const hmac = crypto.createHmac('sha256', signingKey).update(basicParts).digest();

    const tokenBytes = Buffer.concat([basicParts, hmac]);
    return Buffer.from(toBase64UrlPadded(tokenBytes), 'ascii');
  }

  /**
   * Verifies HMAC-SHA256 and decrypts a Fernet token back into plaintext bytes.
   */
  public static decrypt(tokenBuffer: Buffer, rawKey: string): {
    plaintext: Buffer;
    encryptedAt: string;
  } {
    if (!tokenBuffer || tokenBuffer.length === 0) {
      throw new FernetError('EMPTY_INPUT', 'The selected encrypted file is empty.');
    }

    const { signingKey, encryptionKey } = FernetCipher.parseKey(rawKey);
    const tokenString = tokenBuffer.toString('utf8').trim();
    const tokenBytes = fromBase64UrlStrict(
      tokenString,
      'CORRUPTED_TOKEN',
      'Encrypted file payload'
    );

    if (tokenBytes.length < FernetCipher.MIN_TOKEN_BYTES) {
      throw new FernetError(
        'CORRUPTED_TOKEN',
        'The encrypted file is truncated or corrupted and cannot be verified.'
      );
    }

    if (tokenBytes[0] !== FernetCipher.VERSION) {
      throw new FernetError(
        'CORRUPTED_TOKEN',
        'Unsupported or corrupted encrypted file header (invalid Fernet version byte).'
      );
    }

    const hmacOffset = tokenBytes.length - 32;
    const basicParts = tokenBytes.subarray(0, hmacOffset);
    const providedHmac = tokenBytes.subarray(hmacOffset);
    const expectedHmac = crypto.createHmac('sha256', signingKey).update(basicParts).digest();

    if (!crypto.timingSafeEqual(providedHmac, expectedHmac)) {
      throw new FernetError(
        'WRONG_KEY',
        'Decryption failed: the encryption key is incorrect, or the encrypted file has been tampered with or corrupted.'
      );
    }

    const timestampSeconds = Number(basicParts.readBigUInt64BE(1));
    const iv = basicParts.subarray(9, 25);
    const ciphertext = basicParts.subarray(25);

    if (ciphertext.length === 0 || ciphertext.length % 16 !== 0) {
      throw new FernetError(
        'CORRUPTED_TOKEN',
        'Encrypted payload block length is invalid or corrupted.'
      );
    }

    try {
      const decipher = crypto.createDecipheriv('aes-128-cbc', encryptionKey, iv);
      const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
      const encryptedAt = Number.isFinite(timestampSeconds)
        ? new Date(timestampSeconds * 1000).toISOString()
        : new Date().toISOString();

      return { plaintext, encryptedAt };
    } catch {
      throw new FernetError(
        'CORRUPTED_TOKEN',
        'Encrypted data padding is invalid. The file appears to be corrupted.'
      );
    }
  }
}
