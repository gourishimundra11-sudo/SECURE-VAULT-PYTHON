import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

export type OperationType = 'encrypt' | 'decrypt';
export type OperationStatus = 'success' | 'failed';

export interface ActivityRecord {
  id: string;
  filename: string;
  operation: OperationType;
  timestamp: string;
  status: OperationStatus;
  outputFilename: string | null;
  outputLocation: string | null;
  inputSizeBytes: number;
  outputSizeBytes: number | null;
  message: string;
}

export interface VaultFileSummary {
  filename: string;
  category: 'samples' | 'encrypted' | 'decrypted' | 'keys';
  sizeBytes: number;
  updatedAt: string;
  relativePath: string;
}

export class VaultPathError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'VaultPathError';
  }
}

export class VaultManager {
  public readonly rootDir: string;
  public readonly samplesDir: string;
  public readonly encryptedDir: string;
  public readonly decryptedDir: string;
  public readonly keysDir: string;
  public readonly logsDir: string;
  public readonly historyPath: string;
  public readonly logPath: string;

  constructor(baseDir: string = path.resolve(process.cwd(), 'vault_data')) {
    this.rootDir = baseDir;
    this.samplesDir = path.join(this.rootDir, 'samples');
    this.encryptedDir = path.join(this.rootDir, 'encrypted');
    this.decryptedDir = path.join(this.rootDir, 'decrypted');
    this.keysDir = path.join(this.rootDir, 'keys');
    this.logsDir = path.join(this.rootDir, 'logs');
    this.historyPath = path.join(this.rootDir, 'history.json');
    this.logPath = path.join(this.logsDir, 'securevault.log');
  }

  public async initialize(): Promise<void> {
    await Promise.all([
      fs.mkdir(this.samplesDir, { recursive: true }),
      fs.mkdir(this.encryptedDir, { recursive: true }),
      fs.mkdir(this.decryptedDir, { recursive: true }),
      fs.mkdir(this.keysDir, { recursive: true }),
      fs.mkdir(this.logsDir, { recursive: true }),
    ]);

    // Ensure history file exists
    try {
      await fs.access(this.historyPath);
    } catch {
      await fs.writeFile(this.historyPath, '[]\n', 'utf8');
    }

    // Seed academic sample .txt files if samples directory is empty
    const existingSamples = await fs.readdir(this.samplesDir);
    if (existingSamples.length === 0) {
      await fs.writeFile(
        path.join(this.samplesDir, 'research_notes.txt'),
        [
          'SecureVault Academic Cryptography Sample',
          'Project: File Encryption & Decryption Utility',
          'Algorithm: Fernet Symmetric Encryption (AES-128-CBC + HMAC-SHA256)',
          '',
          'Confidentiality Notice:',
          'This sample document contains sensitive research observations intended to verify',
          'end-to-end encryption, integrity verification, and safe file recovery workflows.',
          '',
          'Checklist:',
          '1. Encrypt this .txt file into a .enc ciphertext artifact.',
          '2. Store the generated 32-byte URL-safe Base64 key separately.',
          '3. Decrypt the .enc artifact and verify byte-exact content restoration.',
        ].join('\n'),
        'utf8'
      );

      await fs.writeFile(
        path.join(this.samplesDir, 'incident_response_memo.txt'),
        [
          'Incident Review Summary — Internal Lab Draft',
          'Reference ID: SEC-2026-0419',
          '',
          'Key rotation verified across staging storage buckets.',
          'All archival text logs must be encrypted using Fernet prior to off-site backup.',
          'Never transmit symmetric keys over unencrypted email or store keys inside log files.',
        ].join('\n'),
        'utf8'
      );
    }
  }

  /**
   * Sanitizes a user-supplied filename and validates strict directory confinement.
   */
  public resolveSafePath(targetDir: string, rawFilename: string): {
    safeName: string;
    fullPath: string;
  } {
    if (typeof rawFilename !== 'string' || !rawFilename.trim()) {
      throw new VaultPathError('Invalid file path: filename cannot be empty.');
    }
    if (rawFilename.includes('\0') || rawFilename.includes('..') || rawFilename.includes('/') || rawFilename.includes('\\')) {
      throw new VaultPathError('Invalid file path: directory traversal or path separators are not permitted.');
    }

    const base = path.basename(rawFilename.trim());
    const cleaned = base.replace(/[^a-zA-Z0-9._-]/g, '_');

    if (!cleaned || cleaned === '.' || cleaned === '..' || cleaned.startsWith('.')) {
      throw new VaultPathError('Invalid file path: filename contains unsupported characters.');
    }

    const resolvedDir = path.resolve(targetDir);
    const resolvedFile = path.resolve(resolvedDir, cleaned);
    if (!resolvedFile.startsWith(resolvedDir + path.sep)) {
      throw new VaultPathError('Invalid file path: resolved location escapes the vault directory.');
    }

    return { safeName: cleaned, fullPath: resolvedFile };
  }

  /**
   * Generates a collision-safe output path so existing files are never silently overwritten.
   */
  public async resolveUniqueOutputPath(
    targetDir: string,
    desiredFilename: string
  ): Promise<{
    filename: string;
    fullPath: string;
    relativePath: string;
    renamedDueToDuplicate: boolean;
  }> {
    const { safeName } = this.resolveSafePath(targetDir, desiredFilename);
    const ext = path.extname(safeName);
    const stem = safeName.slice(0, safeName.length - ext.length) || 'output';

    let candidate = safeName;
    let candidatePath = path.resolve(targetDir, candidate);
    let renamedDueToDuplicate = false;

    const exists = async (p: string) => {
      try {
        await fs.access(p);
        return true;
      } catch {
        return false;
      }
    };

    if (await exists(candidatePath)) {
      renamedDueToDuplicate = true;
      const now = new Date();
      const stamp = [
        now.getFullYear(),
        String(now.getMonth() + 1).padStart(2, '0'),
        String(now.getDate()).padStart(2, '0'),
        '_',
        String(now.getHours()).padStart(2, '0'),
        String(now.getMinutes()).padStart(2, '0'),
        String(now.getSeconds()).padStart(2, '0'),
      ].join('');

      let counter = 0;
      while (true) {
        const suffix = counter === 0 ? `_${stamp}` : `_${stamp}_${counter}`;
        candidate = `${stem}${suffix}${ext}`;
        const checked = this.resolveSafePath(targetDir, candidate);
        candidatePath = checked.fullPath;
        if (!(await exists(candidatePath))) {
          break;
        }
        counter += 1;
      }
    }

    const relativePath = path.relative(process.cwd(), candidatePath).replace(/\\/g, '/');
    return {
      filename: candidate,
      fullPath: candidatePath,
      relativePath,
      renamedDueToDuplicate,
    };
  }

  public getDirectoryForCategory(category: 'samples' | 'encrypted' | 'decrypted' | 'keys'): string {
    switch (category) {
      case 'samples':
        return this.samplesDir;
      case 'encrypted':
        return this.encryptedDir;
      case 'decrypted':
        return this.decryptedDir;
      case 'keys':
        return this.keysDir;
    }
  }

  public async listFiles(category: 'samples' | 'encrypted' | 'decrypted' | 'keys'): Promise<VaultFileSummary[]> {
    const dir = this.getDirectoryForCategory(category);
    const entries = await fs.readdir(dir, { withFileTypes: true });
    const files: VaultFileSummary[] = [];

    for (const entry of entries) {
      if (!entry.isFile() || entry.name.startsWith('.')) {
        continue;
      }
      const fullPath = path.join(dir, entry.name);
      const stat = await fs.stat(fullPath);
      files.push({
        filename: entry.name,
        category,
        sizeBytes: stat.size,
        updatedAt: stat.mtime.toISOString(),
        relativePath: path.relative(process.cwd(), fullPath).replace(/\\/g, '/'),
      });
    }

    return files.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }

  /**
   * Appends a sanitized audit event to securevault.log.
   * Never records encryption keys, key material, or file plaintext.
   */
  public async writeAuditLog(
    level: 'INFO' | 'WARNING' | 'ERROR',
    event: string,
    detail: string
  ): Promise<void> {
    const line = `${new Date().toISOString()} [${level}] ${event} - ${detail.replace(/[\r\n]+/g, ' ')}\n`;
    await fs.appendFile(this.logPath, line, 'utf8');
  }

  public async readHistory(): Promise<ActivityRecord[]> {
    try {
      const raw = await fs.readFile(this.historyPath, 'utf8');
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  public async appendHistory(entry: Omit<ActivityRecord, 'id' | 'timestamp'>): Promise<ActivityRecord> {
    const record: ActivityRecord = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      ...entry,
    };

    const current = await this.readHistory();
    const updated = [record, ...current].slice(0, 500);
    await fs.writeFile(this.historyPath, JSON.stringify(updated, null, 2), 'utf8');
    return record;
  }
}

export function formatSafeUserError(error: unknown): { statusCode: number; message: string } {
  if (error instanceof VaultPathError) {
    return { statusCode: 400, message: error.message };
  }
  if (error instanceof Error && error.name === 'FernetError') {
    return { statusCode: 400, message: error.message };
  }

  const nodeErr = error as NodeJS.ErrnoException | undefined;
  if (nodeErr?.code === 'EACCES' || nodeErr?.code === 'EPERM') {
    return {
      statusCode: 500,
      message: 'Permission denied while accessing vault storage. Check directory write permissions.',
    };
  }
  if (nodeErr?.code === 'ENOENT') {
    return {
      statusCode: 404,
      message: 'The requested file could not be found in the vault.',
    };
  }

  return {
    statusCode: 500,
    message: 'An unexpected processing error occurred. Please verify your file and try again.',
  };
}
